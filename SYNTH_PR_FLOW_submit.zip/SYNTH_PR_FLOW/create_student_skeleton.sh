#!/usr/bin/env bash
# =============================================================================
# create_student_skeleton.sh
#
# Empties all user-defined source files, leaving only stub headers.
# Students must fill in each file following the lab guide.
#
# PDK files (lib/, lef/, captable/, QRC_Tech/) are NOT touched.
# Infrastructure files (run_flow.sh, clean.sh, with_cadence.sh) are NOT touched.
#
# WARNING: This script DESTROYS source code. Run it on a COPY of SOLUTION/,
#          never on the original. The original SOLUTION/ is the answer key.
#
# Usage:
#   cp -r SOLUTION STUDENT_LAB
#   cd STUDENT_LAB
#   bash create_student_skeleton.sh
# =============================================================================

set -e
cd "$(dirname "$0")"

echo "================================================================"
echo "  Creating student skeleton -- emptying user-defined files"
echo "================================================================"
echo ""

# ── Helper: write a stub file ────────────────────────────────────────────────
stub() {
    local file="$1"
    shift
    echo "  stub: $file"
    mkdir -p "$(dirname "$file")"
    printf '%s\n' "$@" > "$file"
}

# ═══════════════════════════════════════════════════════════════════════════════
# 1. RTL
# ═══════════════════════════════════════════════════════════════════════════════
stub rtl/fir4.sv \
    "// =============================================================================" \
    "// fir4.sv -- 4-tap symmetric FIR low-pass filter" \
    "// Coefficients: [1, 3, 3, 1] / 8" \
    "// y[n] = ( x[n] + x[n-3] + 3*(x[n-1] + x[n-2]) ) / 8" \
    "//" \
    "// TODO: Implement the following modules:" \
    "//   1. fir4_stage1 -- two pre-adds (9-bit output)" \
    "//   2. fir4_stage2 -- multiply-by-3 + passthrough" \
    "//   3. fir4_stage3 -- final add + right-shift by 3" \
    "//   4. fir4 (top)  -- delay line + stage instantiation + sign extension" \
    "//" \
    "// Requirements:" \
    "//   - 3-stage pipeline, 3-clock latency, 300 MHz target" \
    "//   - 8-bit signed input, 11-bit signed output" \
    "//   - Async active-low reset (rst_b)" \
    "//   - DFT ports: scan_en, test_mode, scan_in, scan_out" \
    "//   - Use exact minimum bit-widths (see lab guide)" \
    "// =============================================================================" \
    ""

# ═══════════════════════════════════════════════════════════════════════════════
# 2. Timing constraints
# ═══════════════════════════════════════════════════════════════════════════════
stub constraints/fir4.sdc \
    "# =============================================================================" \
    "# fir4.sdc -- Timing constraints for 300 MHz target" \
    "#" \
    "# TODO: Define the following:" \
    "#   1. Clock: 3.333 ns period, 50/50 duty cycle" \
    "#   2. Clock uncertainty: setup 50 ps, hold 30 ps" \
    "#   3. Input delays: 20% of period (0.67 ns max)" \
    "#   4. Output delays: 0.67 ns max" \
    "#   5. Output load: 5 fF" \
    "#   6. Max fanout: 20, max transition: 200 ps" \
    "#   7. False paths on rst_b and DFT ports" \
    "#   8. Case analysis 0 on scan_en, test_mode" \
    "# =============================================================================" \
    ""

# ═══════════════════════════════════════════════════════════════════════════════
# 3. Testbench
# ═══════════════════════════════════════════════════════════════════════════════
stub tb/tb_fir4.sv \
    "// =============================================================================" \
    "// tb_fir4.sv -- Self-checking testbench for the fir4 FIR filter" \
    "//" \
    "// TODO: Implement:" \
    "//   1. Clock generation (300 MHz)" \
    "//   2. DUT instantiation with .*" \
    "//   3. SDF annotation block (ifdef TIMING)" \
    "//   4. INPUT_DLY for timing GLS (200 ps in TIMING mode)" \
    "//   5. MATLAB vector loading (readmemh stim/expected hex files)" \
    "//   6. Driving loop with pipeline drain (PIPE_LAT + 4 extra cycles)" \
    "//   7. Output comparison at negedge clk" \
    "//   8. Inline fallback tests (impulse, step, reset)" \
    "//   9. PASS/FAIL summary" \
    "// =============================================================================" \
    "\`timescale 1ns/1ps" \
    ""

# ═══════════════════════════════════════════════════════════════════════════════
# 4. MATLAB
# ═══════════════════════════════════════════════════════════════════════════════
stub matlab/fir4_golden.m \
    "% =============================================================================" \
    "% fir4_golden.m -- Golden reference model for the 4-tap FIR" \
    "%" \
    "% TODO: Implement:" \
    "%   1. Exact model: b = [1 3 3 1]/8, y = filter(b, 1, x)" \
    "%   2. RTL model: y = floor((sum_a + prod_b) / 8)" \
    "%   3. Impulse, step, and sinusoid comparison tables" \
    "%   4. Optional plotting (fir4_golden('plot'))" \
    "% =============================================================================" \
    "function fir4_golden(varargin)" \
    "    % YOUR CODE HERE" \
    "end"

stub matlab/fir4_gen_vectors.m \
    "% =============================================================================" \
    "% fir4_gen_vectors.m -- Generate stimulus + expected output hex files" \
    "%" \
    "% TODO: Implement:" \
    "%   1. 8 test patterns: impulse, step, ramp, low-freq sin," \
    "%      high-freq sin, chirp, random, saturation corners" \
    "%   2. RTL model to compute expected outputs" \
    "%   3. Write tb/stim_vectors.hex (8-bit signed hex)" \
    "%   4. Write tb/expected_vectors.hex (11-bit signed hex)" \
    "% =============================================================================" \
    "function fir4_gen_vectors(varargin)" \
    "    % YOUR CODE HERE" \
    "end"

stub matlab/fir4_visualize.m \
    "% =============================================================================" \
    "% fir4_visualize.m -- 6 publication-quality figures" \
    "%" \
    "% TODO: Implement figures:" \
    "%   1. Frequency response (magnitude + phase)" \
    "%   2. Pole-zero plot (z-plane)" \
    "%   3. Impulse response (exact vs RTL)" \
    "%   4. Chirp test (frequency sweep)" \
    "%   5. Spectrogram (before/after filtering)" \
    "%   6. Quantization error analysis" \
    "% =============================================================================" \
    "function fir4_visualize()" \
    "    % YOUR CODE HERE" \
    "end"

stub matlab/fir4_run_all.m \
    "% =============================================================================" \
    "% fir4_run_all.m -- Master launcher" \
    "%" \
    "% TODO: Call fir4_golden, fir4_gen_vectors, fir4_visualize" \
    "% =============================================================================" \
    "function fir4_run_all()" \
    "    % YOUR CODE HERE" \
    "end"

# ═══════════════════════════════════════════════════════════════════════════════
# 5. Genus synthesis scripts
# ═══════════════════════════════════════════════════════════════════════════════
stub scripts/setup.tcl \
    "# =============================================================================" \
    "# setup.tcl -- Library and LEF configuration for Genus" \
    "#" \
    "# TODO:" \
    "#   1. Set DESIGN_NAME, TOP_MODULE, PROJECT_DIR, OUT_DIR" \
    "#   2. Load slow_vdd1v0 Liberty (.lib) for basicCells + multibitsDFF" \
    "#   3. Load gsclib045 LEF (tech + macro)" \
    "#   4. Set dont_use on weak-drive cells (*X0) and utility cells (FILL*)" \
    "# =============================================================================" \
    ""

stub scripts/read_rtl.tcl \
    "# =============================================================================" \
    "# read_rtl.tcl -- Read, elaborate, and protect RTL hierarchy" \
    "#" \
    "# TODO:" \
    "#   1. Disable auto_ungroup" \
    "#   2. read_hdl fir4.sv with -define DFT_INSERTION" \
    "#   3. elaborate top module" \
    "#   4. check_design (-unresolved, -multiple_driver)" \
    "#   5. set_dont_touch on u_stage1/2/3 instances and designs" \
    "# =============================================================================" \
    ""

stub scripts/syn.tcl \
    "# =============================================================================" \
    "# syn.tcl -- Genus synthesis flow" \
    "#" \
    "# TODO: Implement 9-step flow:" \
    "#   1. source setup.tcl" \
    "#   2. source read_rtl.tcl" \
    "#   3. read_sdc fir4.sdc" \
    "#   4. syn_generic (effort high)" \
    "#   5. syn_map (effort high)" \
    "#   6. syn_opt (effort high, retime=false, auto_ungroup=none)" \
    "#   7. DFT: define_dft, convert_to_scan, connect_scan_chains" \
    "#   8. remove_assigns_without_optimization + dont_touch buffers" \
    "#   9. write_hdl, write_sdc, write_db, write_sdf, reports" \
    "# =============================================================================" \
    ""

# ═══════════════════════════════════════════════════════════════════════════════
# 6. Innovus P&R scripts
# ═══════════════════════════════════════════════════════════════════════════════
stub innovus/scripts/mmmc.tcl \
    "# =============================================================================" \
    "# mmmc.tcl -- Multi-Mode Multi-Corner setup" \
    "#" \
    "# TODO:" \
    "#   1. Create library sets: libs_slow (setup), libs_fast (hold)" \
    "#   2. Create RC corners: rc_worst (125C), rc_best (-40C)" \
    "#   3. Create delay corners: dc_setup, dc_hold" \
    "#   4. Create analysis views: view_setup, view_hold" \
    "#   5. set_analysis_view (must be inside init_design scope)" \
    "# =============================================================================" \
    ""

stub innovus/scripts/01_init.tcl \
    "# =============================================================================" \
    "# 01_init.tcl -- Design initialization" \
    "#" \
    "# TODO:" \
    "#   1. Set init_lef_file (tech + macro LEF)" \
    "#   2. Set init_mmmc_file (mmmc.tcl)" \
    "#   3. Set init_verilog (synthesis netlist)" \
    "#   4. setDesignMode -process 45" \
    "#   5. init_design" \
    "#   6. defIn scan DEF" \
    "#   7. saveDesign" \
    "# =============================================================================" \
    ""

stub innovus/scripts/02_floorplan.tcl \
    "# =============================================================================" \
    "# 02_floorplan.tcl -- Floorplan, pin placement, power planning" \
    "#" \
    "# TODO:" \
    "#   1. floorPlan: aspect 1:1, 70% utilization, 2um margins" \
    "#   2. Pin placement: LEFT(clk,rst,valid_in), TOP(x), RIGHT(y,valid_out)" \
    "#   3. addRing: Metal3/Metal4, 0.4um width" \
    "#   4. addStripe: Metal4 vertical" \
    "#   5. sroute: connect stripes to ring" \
    "# =============================================================================" \
    ""

stub innovus/scripts/03_place.tcl \
    "# =============================================================================" \
    "# 03_place.tcl -- Timing-driven placement" \
    "#" \
    "# TODO:" \
    "#   1. setPlaceMode -timingDriven true" \
    "#   2. place_design" \
    "#   3. optDesign -preCTS" \
    "#   4. saveDesign" \
    "# =============================================================================" \
    ""

stub innovus/scripts/04_cts.tcl \
    "# =============================================================================" \
    "# 04_cts.tcl -- Clock tree synthesis" \
    "#" \
    "# TODO:" \
    "#   1. Set CTS buffer/inverter cells (CLKBUFX2/X4/X8, CLKINVX2/X4)" \
    "#   2. Set target skew (50 ps) and max transition (100 ps)" \
    "#   3. clock_opt_design" \
    "#   4. optDesign -postCTS (setup)" \
    "#   5. optDesign -postCTS -hold" \
    "#   6. saveDesign" \
    "# =============================================================================" \
    ""

stub innovus/scripts/05_route.tcl \
    "# =============================================================================" \
    "# 05_route.tcl -- Detail routing and post-route optimization" \
    "#" \
    "# TODO:" \
    "#   1. route_design (timing-driven, SI-driven)" \
    "#   2. optDesign -postRoute (setup + hold, OCV, high effort)" \
    "#   3. addFiller (FILL64 down to FILL1)" \
    "#   4. verifyGeometry + verifyConnectivity" \
    "#   5. verify_process_antenna" \
    "#   6. saveDesign" \
    "# =============================================================================" \
    ""

stub innovus/scripts/06_signoff.tcl \
    "# =============================================================================" \
    "# 06_signoff.tcl -- RC extraction, timing reports, output generation" \
    "#" \
    "# TODO:" \
    "#   1. extractRC (postRoute engine, QRC tech)" \
    "#   2. report_timing: setup (view_setup) + hold (view_hold)" \
    "#   3. Write SPEF, SDF, GDS, DEF" \
    "#   4. saveNetlist (final gate-level for LEC + GLS)" \
    "#   5. saveDesign" \
    "# =============================================================================" \
    ""

stub innovus/scripts/run_all.tcl \
    "# =============================================================================" \
    "# run_all.tcl -- Source all 6 P&R stages in sequence" \
    "#" \
    "# TODO: source 01_init through 06_signoff" \
    "# =============================================================================" \
    ""

stub innovus/scripts/write_cdl.tcl \
    "# =============================================================================" \
    "# write_cdl.tcl -- Export CDL netlist for LVS" \
    "#" \
    "# TODO:" \
    "#   1. restoreDesign (signoff checkpoint)" \
    "#   2. saveNetlist -format cdl -flat -includePhysicalCells" \
    "# =============================================================================" \
    ""

# ═══════════════════════════════════════════════════════════════════════════════
# 7. LEC scripts
# ═══════════════════════════════════════════════════════════════════════════════
stub fv/fir4/run_lec_synth.do \
    "// =============================================================================" \
    "// run_lec_synth.do -- Post-synthesis LEC (RTL vs Genus netlist)" \
    "//" \
    "// TODO:" \
    "//   1. Read Liberty libraries (-both)" \
    "//   2. Read golden: rtl/fir4.sv (-sv)" \
    "//   3. Read revised: output/fir4_netlist.v (-verilog)" \
    "//   4. Pin constraints: scan_en=0, test_mode=0, scan_in=0" \
    "//   5. Ignore output: scan_out" \
    "//   6. set system mode lec, add compared points, compare" \
    "//   7. Reports: verification, compare data, unmapped, statistics" \
    "// =============================================================================" \
    ""

stub fv/fir4/run_lec.do \
    "// =============================================================================" \
    "// run_lec.do -- Post-P&R LEC (RTL vs Innovus final netlist)" \
    "//" \
    "// TODO: Same as run_lec_synth.do but revised = final_netlist.v" \
    "// =============================================================================" \
    ""

# NOTE: Shell drivers (run_lec_synth.sh, run_lec.sh, clean.sh) are
# infrastructure -- kept intact so the flow can run.

# ═══════════════════════════════════════════════════════════════════════════════
# 8. Simulation drivers (infrastructure -- keep headers, empty body)
# ═══════════════════════════════════════════════════════════════════════════════
stub scripts/run_rtl_sim.sh \
    "#!/bin/bash" \
    "# =============================================================================" \
    "# run_rtl_sim.sh -- RTL simulation driver" \
    "#" \
    "# TODO:" \
    "#   1. Set paths (PROJECT_DIR, TB, RTL)" \
    "#   2. Source with_cadence.sh for cadence_run wrapper" \
    "#   3. cadence_run xrun -sv -access +rwc -timescale 1ns/1ps" \
    "#   4. GUI mode: add -gui -input sim_gui.tcl" \
    "#   5. Check log for TEST PASSED" \
    "# =============================================================================" \
    ""

stub scripts/run_gls.sh \
    "#!/bin/bash" \
    "# =============================================================================" \
    "# run_gls.sh -- Gate-level simulation driver (functional + timing)" \
    "#" \
    "# TODO:" \
    "#   1. Two modes: TIMING=0 (functional), TIMING=1 (SDF)" \
    "#   2. Cell models: -v slow_vdd1v0_basicCells.v (library mode)" \
    "#   3. Timing mode: -define TIMING, -define SDF_FILE, -nowarn SDFINF/SDFNSB/SDFNET" \
    "#   4. GUI mode: -gui -input sim_gui.tcl" \
    "#   5. SDF annotation summary + TEST PASSED check" \
    "# =============================================================================" \
    ""

echo ""
echo "================================================================"
echo "  Skeleton created. All user-defined files now contain only"
echo "  stub headers with TODO instructions."
echo ""
echo "  Files preserved (infrastructure):"
echo "    run_flow.sh, clean.sh, scripts/with_cadence.sh"
echo "    fv/fir4/run_lec_synth.sh, fv/fir4/run_lec.sh"
echo "    fv/fir4/clean.sh"
echo "    lib/*, lef/*, captable/*, QRC_Tech/*"
echo ""
echo "  Follow STUDENT_LAB_GUIDE.pdf to fill in each file."
echo "================================================================"
