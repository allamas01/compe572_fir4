
# XM-Sim Command File
# TOOL:   xrun(64)  25.03-s010
# Design: fir4 -- 4-tap symmetric FIR low-pass filter
#
# You can restore this configuration with:
#
#    xrun -sv -access +rwc -timescale 1ns/1ps -top tb_fir4 \
#         rtl/fir4.sv tb/tb_fir4.sv -input scripts/restore.tcl
#
# This file follows the Cadence xmsim "restore" pattern:
#   1. Sets a baseline of xrun Tcl interpreter options
#   2. Opens the waveform database + probes the full testbench
#   3. Runs the testbench to completion ($finish)
#   4. Calls `simvision` (xrun's Tcl-level command, NOT the broken
#      Incisive 15.2 simvision on PATH) to launch the GUI on the
#      waveform database. xrun resolves simvision via its own
#      internal lookup, bypassing the PATH wrapper.
#

# ---- 1. Baseline xrun Tcl interpreter settings ------------------------------
set tcl_prompt1 {puts -nonewline "xcelium> "}
set tcl_prompt2 {puts -nonewline "> "}
set vlog_format %h
set vhdl_format %v
set real_precision 6
set display_unit auto
set time_unit module
set heap_garbage_size -200
set heap_garbage_time 0
set assert_report_level note
set assert_stop_level error
set autoscope yes
set assert_1164_warnings yes
set pack_assert_off {}
set severity_pack_assert_off {note warning}
set assert_output_stop_level failed
set tcl_debug_level 0
set relax_path_name 1
set vhdl_vcdmap XX01ZX01X
set intovf_severity_level ERROR
set probe_screen_format 0
set rangecnst_severity_level ERROR
set textio_severity_level ERROR
set vital_timing_checks_on 1
set vlog_code_show_force 0
set assert_count_attempts 1
set tcl_all64 false
set tcl_runerror_exit false
set assert_report_incompletes 0
set show_force 1
set force_reset_by_reinvoke 0
set tcl_relaxed_literal 0
set probe_exclude_patterns {}
set probe_packed_limit 4k
set probe_unpacked_limit 16k
set assert_internal_msg no
set svseed 1
set assert_reporting_mode 0
set vcd_compact_mode 0
alias . run
alias quit exit

# ---- 2. Waveform database + full-hierarchy probe ---------------------------
database -open -shm -into waves.shm fir4_db -default
probe    -create -database fir4_db tb_fir4 -all -depth all

# ---- 3. Run testbench to completion ----------------------------------------
run

# ---- 4. Launch SimVision via xrun's Tcl-level command ----------------------
# NOTE: `simvision` here is the xrun-built-in Tcl command, NOT the shell
# `simvision` binary on PATH (which is the legacy Incisive 15.2 install
# missing libX11). xrun knows where the Xcelium 25.x SimVision lives
# inside the Apptainer container and launches it correctly.
simvision -input ./scripts/restore.tcl.svcf
