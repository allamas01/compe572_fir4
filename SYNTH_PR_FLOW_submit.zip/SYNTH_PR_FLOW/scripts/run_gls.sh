#!/bin/bash
# =============================================================================
# run_gls.sh -- Gate-level simulation driver (functional + timing)
#
# Usage:
#   bash scripts/run_gls.sh                 # functional GLS (no SDF)
#   TIMING=1 bash scripts/run_gls.sh        # timing GLS (SDF back-annotation)
#   GUI=1 [TIMING=1] bash scripts/run_gls.sh   # SimVision waveforms
#
# Logs: output/gls_functional.log, output/gls_timing.log
# =============================================================================
set -e
TIMING=${TIMING:-0}
GUI=${GUI:-0}
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NETLIST="${PROJECT_DIR}/innovus/output/fir4_final_netlist.v"
SDF="${PROJECT_DIR}/innovus/output/fir4.sdf"
CELL_MODELS="${PROJECT_DIR}/lib/slow_vdd1v0_basicCells.v"
TB="${PROJECT_DIR}/tb/tb_fir4.sv"

# The testbench reads tb/*.hex relative to the project root.
cd "${PROJECT_DIR}"
mkdir -p output

. "${PROJECT_DIR}/scripts/with_cadence.sh"

GUI_OPTS=""
if [ "$GUI" -eq 1 ]; then
    GUI_OPTS="-gui -input '${PROJECT_DIR}/scripts/sim_gui.tcl'"
fi

if [ $TIMING -eq 1 ]; then
    LOG="${PROJECT_DIR}/output/gls_timing.log"
    cadence_run "xrun -sv -access +rwc -timescale 1ns/1ps -top tb_fir4 \
        -nowarn SDFINF -nowarn SDFNSB -nowarn SDFNET \
        -define TIMING -define SDF_FILE='\\\"${SDF}\\\"' \
        ${GUI_OPTS} \
        -v '${CELL_MODELS}' '${NETLIST}' '${TB}' -log '${LOG}'"
else
    LOG="${PROJECT_DIR}/output/gls_functional.log"
    cadence_run "xrun -sv -access +rwc -timescale 1ns/1ps -top tb_fir4 \
        -define FUNCTIONAL \
        ${GUI_OPTS} \
        -v '${CELL_MODELS}' '${NETLIST}' '${TB}' -log '${LOG}'"
fi

[ "$GUI" -eq 1 ] && exit 0

echo ""
grep -E "SDF:|outputs matched|valid_out=0|mismatch|Summary|TEST (PASSED|FAILED)" "${LOG}" || true

if grep -q "TEST PASSED" "${LOG}"; then
    echo " RESULT: PASS"
else
    echo " RESULT: FAIL -- review ${LOG}"
    exit 1
fi
