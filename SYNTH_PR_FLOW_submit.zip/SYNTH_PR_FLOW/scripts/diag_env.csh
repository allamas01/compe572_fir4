#!/bin/tcsh -f
# =============================================================================
# File   : scripts/diag_env.csh
# Purpose: tcsh-native env diagnostic. Captures shell + module + PATH
#          state into output/env_diag.log so we can pinpoint the
#          stale-Genus / wrong-PATH issue.
#
# Run from your tcsh shell:
#
#     tcsh scripts/diag_env.csh
#
#   or, equivalently:
#
#     ./scripts/diag_env.csh        (after `chmod +x`, which it already has)
#
# Do NOT `source` it -- run it. Sourcing inherits the script's `set`
# state into your interactive shell.
# =============================================================================

# --- locate project root + log path ---
set HERE     = `dirname $0`
set PROJ     = `cd $HERE/.. && pwd`
set OUT      = "$PROJ/output"
set LOG      = "$OUT/env_diag.log"
mkdir -p "$OUT"

# All output goes through tee. We dump to a temp first then tee, so
# the diagnostic doesn't depend on bash's process-substitution.
set TMP      = "$OUT/.env_diag.tmp"
rm -f "$TMP"

# --- run the probes, write to TMP ---------------------------------
( \
echo "==========================================================="; \
echo "  fir4 env diagnostic (tcsh)"; \
echo "  date    : `date`"; \
echo "  host    : `hostname`"; \
echo "  user    : $USER"; \
echo "  cwd     : `pwd`"; \
echo "==========================================================="; \
echo ""; \
echo "----- [1] Caller shell -----------------------------------"; \
echo "  SHELL  : $SHELL"; \
echo "  shell  : $shell"; \
echo "  argv0  : $0"; \
echo ""; \
echo "----- [2] which module -----------------------------------"; \
which module; \
echo "  alias module:"; \
alias module; \
echo ""; \
echo "----- [3] which -a {genus,innovus,xrun,lec} --------------"; \
foreach t ( genus innovus xrun lec ) ; \
    echo "  >>> which -a $t" ; \
    which -a $t ; \
end ; \
echo ""; \
echo "----- [4] PATH (one entry per line) ----------------------"; \
echo $PATH | tr ':' '\n' | nl ; \
echo ""; \
echo "----- [5] module show cadence_ece ------------------------"; \
module show cadence_ece ; \
echo ""; \
echo "----- [6] module list after purge + load ----------------"; \
module purge ; \
module load cadence_ece ; \
module list ; \
echo ""; \
echo "----- [7] which -a genus AFTER module load --------------"; \
which -a genus ; \
echo ""; \
echo "----- [8] PATH AFTER module load ------------------------"; \
echo $PATH | tr ':' '\n' | nl ; \
echo ""; \
echo "----- [9] genus -version --------------------------------"; \
( genus -version |& head -3 ) ; \
echo ""; \
echo "==========================================================="; \
echo "  end of env diagnostic"; \
echo "==========================================================="; \
) >& "$TMP"

# --- copy to log + show on screen --------------------------------
cp "$TMP" "$LOG"
cat "$LOG"
rm -f "$TMP"

echo ""
echo "Wrote $LOG"
echo "Paste the contents of $LOG when asking for help."
