#!/bin/bash
# =============================================================================
# File   : scripts/diag_env.sh
# Purpose: Capture exactly what your shell + the cadence_ece module look
#          like RIGHT NOW, into a log file, so we can debug the
#          module/PATH issue without guessing.
#
# Usage:
#   bash scripts/diag_env.sh
#       -> writes output/env_diag.log
#
# Run this from the SAME terminal you would normally invoke
# `bash run_flow.sh` from. It captures the parent shell's PATH +
# the cadence_ece modulefile's declared paths, so we can compare
# them and see which entries are stale / out of order.
# =============================================================================

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LOG="$PROJECT_DIR/output/env_diag.log"

mkdir -p "$PROJECT_DIR/output"

# Use a function so all output is consistently logged + tee'd.
{
    echo "==========================================================="
    echo "  fir4 env diagnostic"
    echo "  date    : $(date)"
    echo "  host    : $(hostname 2>/dev/null)"
    echo "  user    : ${USER:-$(id -un 2>/dev/null)}"
    echo "  cwd     : $PWD"
    echo "==========================================================="

    echo
    echo "----- [1] Caller shell ($0) ------------------------------"
    echo "  parent SHELL : ${SHELL:-(unset)}"
    echo "  parent PPID  : ${PPID:-(unset)}"
    if [ -n "${PPID:-}" ]; then
        echo "  ps -o args= -p \$PPID :"
        ps -o args= -p "$PPID" 2>/dev/null | sed 's/^/    /'
    fi
    echo "  this script invoked by: $0"
    echo "  bash version inside script: ${BASH_VERSION:-(no BASH_VERSION)}"

    echo
    echo "----- [2] which module --------------------------------"
    which module 2>&1 || true
    echo "  (declare -f / type module:)"
    type module 2>&1 | head -5 || true

    echo
    echo "----- [3] which -a genus innovus xrun lec -----------------"
    for t in genus innovus xrun lec; do
        echo "  >>> which -a $t"
        which -a "$t" 2>&1 | sed 's/^/    /' || true
    done

    echo
    echo "----- [4] PATH (one entry per line, in order) -------------"
    echo "$PATH" | tr ':' '\n' | nl -ba

    echo
    echo "----- [5] module show cadence_ece (current shell) ---------"
    if type module >/dev/null 2>&1; then
        module show cadence_ece 2>&1
    else
        echo "  (module function not available in THIS bash sub-shell --"
        echo "   that is normal; trying again under bash -l below)"
    fi

    echo
    echo "----- [6] module show cadence_ece (bash -l -c) ------------"
    bash -l -c 'module show cadence_ece 2>&1' 2>&1

    echo
    echo "----- [7] module list (bash -l -c after purge+load) -------"
    bash -l -c 'module purge >/dev/null 2>&1; module load cadence_ece >/dev/null 2>&1; module list 2>&1' 2>&1

    echo
    echo "----- [8] which genus inside bash -l -c ------------------"
    bash -l -c 'module purge >/dev/null 2>&1; module load cadence_ece >/dev/null 2>&1; which -a genus 2>&1' 2>&1

    echo
    echo "----- [9] resolved PATH inside bash -l -c -----------------"
    bash -l -c 'module purge >/dev/null 2>&1; module load cadence_ece >/dev/null 2>&1; echo "$PATH"' \
        | tr ':' '\n' | nl -ba

    echo
    echo "----- [10] genus -version ---------------------------------"
    if command -v genus >/dev/null 2>&1; then
        genus -version 2>&1 | head -3
    else
        echo "  (genus not on PATH in current shell)"
    fi
    echo "  --- under bash -l -c module load ---"
    bash -l -c \
      'module purge >/dev/null 2>&1; module load cadence_ece >/dev/null 2>&1; \
       command -v genus && genus -version 2>&1 | head -3' 2>&1

    echo
    echo "==========================================================="
    echo "  end of env diagnostic"
    echo "==========================================================="
} 2>&1 | tee "$LOG"

echo ""
echo "Wrote $LOG"
echo "Paste the contents of $LOG when asking for help."
