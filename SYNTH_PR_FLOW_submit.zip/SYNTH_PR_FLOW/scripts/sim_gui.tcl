# =============================================================================
# File   : scripts/sim_gui.tcl
# Tool   : Cadence Xcelium xrun Tcl interpreter (GUI mode)
# Purpose: Loaded via `xrun -gui -input sim_gui.tcl ...`. xrun's -gui
#          flag launches SimVision; this script seeds the waveform
#          database, probes all signals, and runs the testbench to
#          $finish. SimVision stays open afterward for debug.
# =============================================================================

# ---- 1. Create the waveform database ---------------------------------------
database -open waves -into waves.shm -default
probe    -create tb_fir4 -depth all -all -shm -database waves

# ---- 2. Run the testbench to completion ($finish in the TB ends it) --------
run

# ---- 3. Seed useful signal groups in the waveform window -------------------
catch {
    waveform  new   -name "fir4 -- top-level I/O"
    waveform  add   -signals { tb_fir4.clk   tb_fir4.rst_b }
    waveform  add   -signals { tb_fir4.valid_in  tb_fir4.x \
                               tb_fir4.valid_out tb_fir4.y }
    waveform  add   -signals { tb_fir4.scan_en tb_fir4.test_mode \
                               tb_fir4.scan_in tb_fir4.scan_out }

    waveform  new   -name "fir4 -- pipeline stages"
    catch { waveform add -signals { tb_fir4.dut.x_d1 tb_fir4.dut.x_d2 tb_fir4.dut.x_d3 } }
    catch { waveform add -signals { tb_fir4.dut.u_stage1.sum_a tb_fir4.dut.u_stage1.sum_b } }
    catch { waveform add -signals { tb_fir4.dut.u_stage2.sum_a_out tb_fir4.dut.u_stage2.prod_b_out } }
    catch { waveform add -signals { tb_fir4.dut.u_stage3.result } }
}

# (No `exit` here -- SimVision stays up until the user closes it.)
