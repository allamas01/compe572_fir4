#!/bin/bash
# =============================================================================
# File   : scripts/with_cadence.sh
# Purpose: Shared helper. SOURCE this file from any other bash script
#          that needs to call genus / innovus / xrun / lec.
#
#          Defines one function:
#            cadence_run "<command string>"
#
#          which spawns a fresh login bash, runs `module load
#          cadence_ece`, and then the command. This is REQUIRED on
#          volta because cadence_ece publishes the tools as Apptainer-
#          container shell functions, not as plain binaries on PATH.
#          Shell functions are not inherited by child shells, so the
#          load must happen inside the same bash that ultimately
#          invokes the tool.
#
# Override the module name with $MODULE_NAME if your site differs:
#
#     MODULE_NAME=foo cadence_run "genus -batch -f scripts/syn.tcl"
# =============================================================================

cadence_run() {
    local user_cmd="$*"
    local cwd="$(pwd)"

    # ─── X11 forwarding into the Apptainer container ────────────────────────
    # The cadence_ece module wraps each tool as a shell function that
    # invokes `apptainer exec rocky8_cadence.sif <tool>`. By default
    # Apptainer does NOT mount /tmp/.X11-unix or forward $DISPLAY /
    # $XAUTHORITY, so GUI tools launched through the wrapper (SimVision,
    # Innovus GUI, Genus GUI, Conformal GUI) start but can't connect to
    # your X server and die silently.
    #
    # These env vars tell Apptainer to:
    #   - bind-mount the X11 socket into the container
    #   - pass through $DISPLAY and $XAUTHORITY
    # They must be EXPORTED so the shell function inherits them when it
    # builds its `apptainer exec` command line.
    local x11_env=""
    if [ -n "${DISPLAY:-}" ]; then
        x11_env="export APPTAINER_BIND=\"\${APPTAINER_BIND:-}\${APPTAINER_BIND:+,}/tmp/.X11-unix\"; \
                 export APPTAINERENV_DISPLAY=\"$DISPLAY\"; \
                 export SINGULARITY_BIND=\"\${SINGULARITY_BIND:-}\${SINGULARITY_BIND:+,}/tmp/.X11-unix\"; \
                 export SINGULARITYENV_DISPLAY=\"$DISPLAY\";"
        if [ -n "${XAUTHORITY:-}" ] && [ -r "${XAUTHORITY}" ]; then
            x11_env="${x11_env} \
                 export APPTAINER_BIND=\"\$APPTAINER_BIND,$XAUTHORITY\"; \
                 export APPTAINERENV_XAUTHORITY=\"$XAUTHORITY\"; \
                 export SINGULARITY_BIND=\"\$SINGULARITY_BIND,$XAUTHORITY\"; \
                 export SINGULARITYENV_XAUTHORITY=\"$XAUTHORITY\";"
        fi
    fi

    # Do NOT `module purge` here. cadence_ece depends on pdk, ncsu,
    # and siemens modules (via depends_on in the modulefile). Purging
    # kills those dependencies, and the subsequent `module load
    # cadence_ece` fails silently.
    #
    # Do NOT suppress module load stderr -- if the load fails we need
    # to see the error in the stage log.
    #
    # Explicitly cd back to the caller's CWD after the login shell's
    # profile scripts run -- some sites' /etc/profile or ~/.bash_profile
    # change the working directory to $HOME.
    /bin/bash -l -c \
        "cd '$cwd'; \
         ${x11_env} \
         module load ${MODULE_NAME:-cadence_ece}; \
         $user_cmd"
}
