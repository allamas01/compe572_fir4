#!/bin/bash
# =============================================================================
# File   : scripts/port_design.sh
# Purpose: One-push-button porting of the SYNTH_PR_FLOW template from
#          the shipped design (fir4) to a new design.
#
# What it does (in order):
#   1. Renames DESIGN_NAME / TOP_MODULE in every Genus + Innovus TCL.
#   2. Renames RTL, TB, and SDC references in the shell drivers.
#   3. Renames artifact globs in clean.sh.
#   4. Updates the -top module name for xrun and the sim_gui.tcl probes.
#   5. Updates the LEC dofile + driver with the new RTL/netlist paths.
#   6. Prints a verification report (any stale references left?).
#
# What it does NOT do (you must do these yourself):
#   * Write rtl/<NEW>.sv, constraints/<NEW>.sdc, tb/tb_<NEW>.sv
#   * Edit the port-classification foreach block in 02_floorplan.tcl
#     (your port names differ from fir4's -- the script prints a
#     reminder with the exact lines to change).
#
# Usage:
#   bash scripts/port_design.sh <NEW_DESIGN_NAME>
#
# Example:
#   bash scripts/port_design.sh fir4
#
# Undo: re-clone the template from the course repo.
# =============================================================================
set -e

if [ $# -lt 1 ]; then
    echo "Usage: bash scripts/port_design.sh <NEW_DESIGN_NAME>"
    echo ""
    echo "Example:  bash scripts/port_design.sh fir4"
    exit 1
fi

OLD="fir4"
NEW="$1"
DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$DIR"

echo "============================================================"
echo "  Porting SYNTH_PR_FLOW from '$OLD' to '$NEW'"
echo "  Working directory: $DIR"
echo "============================================================"
echo ""

# ---- helper: sed in-place (GNU + BSD compatible) -------------------------
do_sed() {
    local file="$1"; shift
    # Try GNU sed first; fall back to BSD (macOS) form.
    sed -i "$@" "$file" 2>/dev/null \
        || sed -i '' "$@" "$file"
}

# ---- 1. Genus scripts ----------------------------------------------------
echo "[1/8] Genus scripts (setup.tcl, read_rtl.tcl, syn.tcl)"

do_sed scripts/setup.tcl       "s/\"${OLD}\"/\"${NEW}\"/g"
do_sed scripts/read_rtl.tcl    "s/${OLD}\\.sv/${NEW}.sv/g"
do_sed scripts/syn.tcl         "s/${OLD}\\.sdc/${NEW}.sdc/g"
do_sed scripts/syn.tcl         "s/${OLD}_chain1/${NEW}_chain1/g"

echo "  done."

# ---- 2. Innovus scripts --------------------------------------------------
echo "[2/8] Innovus scripts (mmmc, 01_init..06_signoff, write_cdl, run_all)"

for f in innovus/scripts/mmmc.tcl \
         innovus/scripts/01_init.tcl \
         innovus/scripts/02_floorplan.tcl \
         innovus/scripts/03_place.tcl \
         innovus/scripts/04_cts.tcl \
         innovus/scripts/05_route.tcl \
         innovus/scripts/06_signoff.tcl \
         innovus/scripts/write_cdl.tcl; do
    do_sed "$f" "s/\"${OLD}\"/\"${NEW}\"/g"
done

do_sed innovus/scripts/run_all.tcl "s/${OLD}/${NEW}/g"

echo "  done."

# ---- 3. Simulation drivers -----------------------------------------------
echo "[3/8] Simulation drivers (run_rtl_sim.sh, run_gls.sh)"

do_sed scripts/run_rtl_sim.sh  "s/${OLD}/${NEW}/g"
do_sed scripts/run_rtl_sim.sh  "s/tb_${OLD}/tb_${NEW}/g"

do_sed scripts/run_gls.sh     "s/${OLD}/${NEW}/g"
do_sed scripts/run_gls.sh     "s/tb_${OLD}/tb_${NEW}/g"

echo "  done."

# ---- 4. SimVision GUI script ---------------------------------------------
echo "[4/8] SimVision GUI (sim_gui.tcl)"

do_sed scripts/sim_gui.tcl    "s/${OLD}/${NEW}/g"
do_sed scripts/sim_gui.tcl    "s/tb_${OLD}/tb_${NEW}/g"

echo "  done."

# ---- 5. LEC scripts ------------------------------------------------------
echo "[5/8] LEC (fv/fir4/run_lec.do, fv/fir4/run_lec.sh)"

do_sed fv/fir4/run_lec.do     "s/${OLD}\\.sv/${NEW}.sv/g"
do_sed fv/fir4/run_lec.do     "s/${OLD}_final/${NEW}_final/g"

do_sed fv/fir4/run_lec.sh     "s/${OLD}_final/${NEW}_final/g"
do_sed fv/fir4/run_lec.sh     "s/${OLD}/${NEW}/g"

echo "  done."

# ---- 6. clean.sh artifact globs -----------------------------------------
echo "[6/8] clean.sh (artifact globs)"

do_sed clean.sh                "s/${OLD}/${NEW}/g"

echo "  done."

# ---- 7. Remove old source files ------------------------------------------
echo "[7/8] Removing old source files"

for f in "rtl/${OLD}.sv" "tb/tb_${OLD}.sv" "constraints/${OLD}.sdc"; do
    if [ -f "$f" ]; then
        rm -f "$f"
        echo "  removed: $f"
    fi
done

echo "  done."

# ---- 8. Verify -----------------------------------------------------------
echo ""
echo "[8/8] Verification"
echo ""

# Check for stale OLD references in active code (ignore comments, dir paths).
STALE=$(grep -rn "${OLD}" \
    scripts/setup.tcl scripts/read_rtl.tcl scripts/syn.tcl \
    scripts/run_rtl_sim.sh scripts/run_gls.sh scripts/sim_gui.tcl \
    innovus/scripts/*.tcl \
    fv/fir4/run_lec.do fv/fir4/run_lec.sh \
    clean.sh \
    constraints/ \
    2>/dev/null \
    | grep -v '^\s*#' \
    | grep -v '^\s*//' \
    | grep -v "fv/${OLD}" \
    | grep -v "${OLD}_design_flow" \
    || true)

if [ -z "$STALE" ]; then
    echo "  PASS: no stale '${OLD}' references in active code."
else
    echo "  WARNING: stale '${OLD}' references found:"
    echo "$STALE" | sed 's/^/    /'
    echo ""
    echo "  These may be harmless comments or may need manual fixing."
fi

echo ""

# Check new sources exist.
MISSING=0
for f in "rtl/${NEW}.sv" "tb/tb_${NEW}.sv" "constraints/${NEW}.sdc"; do
    if [ -f "$f" ]; then
        echo "  OK:   $f exists"
    else
        echo "  MISSING: $f -- you need to write this file!"
        MISSING=$((MISSING + 1))
    fi
done

echo ""

# Remind about the manual edit.
echo "============================================================"
echo "  MANUAL EDIT STILL REQUIRED:"
echo "============================================================"
echo ""
echo "  innovus/scripts/02_floorplan.tcl"
echo ""
echo "  The port-classification 'foreach' block must match YOUR"
echo "  design's port names. Open the file and update the block:"
echo ""
echo "    Old (${OLD}):                    New (${NEW}):"
echo "    clk rst_b en        ->    clk rst_b <your_enable>"
echo "    duty[*]             ->    <your_input_bus>[*]"
echo "    pwm_out             ->    <your_scalar_output>"
echo "    count[*]            ->    <your_output_bus>[*]"
echo ""
echo "  Look for the line:"
echo "    if  {\$p in {clk rst_b en}}"
echo "  and update the port names to match your RTL module ports."
echo ""
echo "  After editing, verify with:"
echo "    grep -A8 'foreach p' innovus/scripts/02_floorplan.tcl"
echo ""

if [ $MISSING -gt 0 ]; then
    echo "============================================================"
    echo "  $MISSING source file(s) still missing. Write them, then:"
    echo "    bash run_flow.sh"
    echo "============================================================"
else
    echo "============================================================"
    echo "  All source files present. Ready to run:"
    echo "    bash run_flow.sh"
    echo "============================================================"
fi
