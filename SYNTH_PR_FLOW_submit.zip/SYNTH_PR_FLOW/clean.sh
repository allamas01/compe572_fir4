#!/usr/bin/env bash
# =============================================================================
# clean.sh — remove ALL generated artifacts from every directory
#
# Leaves ONLY source/infrastructure files:
#   rtl/*.sv              (your RTL)
#   tb/tb_*.sv            (your testbench — NOT hex vectors)
#   constraints/*.sdc     (your SDC)
#   scripts/*.tcl *.sh    (flow scripts)
#   innovus/scripts/*.tcl (P&R scripts)
#   fv/fir4/run_lec*.{do,sh}  fv/fir4/clean.sh  (LEC scripts)
#   pvs/scripts/*.sh      pvs/runsets/*.pvl      (PVS scripts)
#   matlab/*.m            (MATLAB sources — NOT generated PDFs/logs)
#   lib/ lef/ captable/ QRC_Tech/  (PDK — never touched)
#   run_flow.sh clean.sh README.txt USAGE.md ECE_GUIDE.html
#
# Usage:
#   ./clean.sh           # delete everything generated
#   ./clean.sh --dry     # show what would be deleted, delete nothing
# =============================================================================

set -e
cd "$(dirname "$0")"

DRY=0
[[ "${1:-}" == "--dry" ]] && DRY=1

nuke() {
    for p in "$@"; do
        for f in $p; do
            [[ -e "$f" || -L "$f" ]] || continue
            if (( DRY )); then
                echo "would remove: $f"
            else
                echo "removing: $f"
                rm -rf "$f"
            fi
        done
    done
}

# ─── Genus outputs (output/) ────────────────────────────────────────────────
nuke \
    output/fir4_netlist.v  \
    output/fir4_out.sdc    \
    output/fir4.db         \
    output/fir4.sdf        \
    output/fir4_scan.def   \
    output/fir4_scan.rpt   \
    output/fir4_*.rpt      \
    output/*.cmd            \
    output/*.cmd[0-9]*      \
    output/*.log            \
    output/*.log[0-9]*      \
    output/*.logv           \
    output/*.history        \
    output/*.db

# ─── Innovus outputs (innovus/output/) ──────────────────────────────────────
nuke \
    innovus/output/fir4_*.enc      \
    innovus/output/fir4_*.enc.dat  \
    innovus/output/fir4_*.rpt      \
    innovus/output/fir4_*.def      \
    innovus/output/fir4_*.v        \
    innovus/output/fir4.spef       \
    innovus/output/fir4.sdf        \
    innovus/output/*.log           \
    innovus/output/*.logv          \
    innovus/output/*.cmd           \
    innovus/output/*.cmd[0-9]*     \
    innovus/output/*.history       \
    innovus/output/*.rpt.nfs_lock_flush

# ─── GDS + CDL handoff ──────────────────────────────────────────────────────
nuke \
    gds/*.gds    \
    cdl/*.cdl

# ─── MATLAB generated artefacts (keep *.m source files) ─────────────────────
nuke \
    tb/stim_vectors.hex       \
    tb/expected_vectors.hex   \
    matlab/*.log              \
    matlab/fig*.pdf           \
    matlab/*.asv

# ─── Simulation artefacts (RTL sim + GLS) ───────────────────────────────────
nuke \
    output/rtl_sim.log        \
    output/gls_functional.log \
    output/gls_timing.log     \
    output/tb_fir4.vcd        \
    xcelium.d                 \
    xrun.d                    \
    xrun.history              \
    xrun.log                  \
    waves.shm                 \
    INCA_libs                 \
    .simvision                \
    .nfs*                     \
    cds.lib                   \
    hdl.var                   \
    *.sdf.X

# ─── Formal verification (LEC + Genus formal-mapping artefacts) ─────────────
if [[ -f fv/fir4/clean.sh ]]; then
    if (( DRY )); then
        bash fv/fir4/clean.sh --dry
    else
        bash fv/fir4/clean.sh
    fi
fi

# ─── PVS outputs ────────────────────────────────────────────────────────────
nuke \
    pvs/output/drc/*          \
    pvs/output/lvs/*

# ─── Signoff / Voltus / RC artefacts that land in project root ──────────────
nuke \
    fir4.conn.rpt                          \
    fir4.antenna.lef                       \
    fir4.checkPin.rpt                      \
    rc_model.bin                           \
    timingReports                          \
    voltus_clocks.txt                      \
    voltus_ports.txt                       \
    voltus_power_analysis_mode.option      \
    voltus_*.txt                           \
    voltus_*.option

# ─── Tool working dirs / top-level junk ─────────────────────────────────────
nuke \
    fe                     \
    fv/fir4/rtl_to_fv_map.do~ \
    fv/fir4/reports/*~     \
    innovus.log            \
    innovus.logv           \
    innovus.cmd            \
    genus.log              \
    genus.logv             \
    genus.cmd              \
    rc.log                 \
    rc.logv                \
    rc.cmd                 \
    *.log                  \
    *.logv                 \
    *.cmd                  \
    *.log~                 \
    *~                     \
    *.bak                  \
    .cadence               \
    .metrics               \
    .rs_*                  \
    .qrc*                  \
    .apa                   \
    .powerAnalysis         \
    .timing*               \
    .sosReport             \
    .encounter*            \
    .innovus*

echo
if (( DRY )); then
    echo "Dry run — nothing deleted. Re-run without --dry to actually clean."
else
    echo "Clean complete."
fi
