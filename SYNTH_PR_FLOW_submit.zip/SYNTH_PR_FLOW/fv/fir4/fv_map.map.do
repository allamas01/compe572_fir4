
//input ports
add mapped point clk clk -type PI PI
add mapped point rst_b rst_b -type PI PI
add mapped point valid_in valid_in -type PI PI
add mapped point x[7] x[7] -type PI PI
add mapped point x[6] x[6] -type PI PI
add mapped point x[5] x[5] -type PI PI
add mapped point x[4] x[4] -type PI PI
add mapped point x[3] x[3] -type PI PI
add mapped point x[2] x[2] -type PI PI
add mapped point x[1] x[1] -type PI PI
add mapped point x[0] x[0] -type PI PI
add mapped point scan_en scan_en -type PI PI
add mapped point test_mode test_mode -type PI PI
add mapped point scan_in scan_in -type PI PI

//output ports
add mapped point valid_out valid_out -type PO PO
add mapped point y[10] y[10] -type PO PO
add mapped point y[9] y[9] -type PO PO
add mapped point y[8] y[8] -type PO PO
add mapped point y[7] y[7] -type PO PO
add mapped point y[6] y[6] -type PO PO
add mapped point y[5] y[5] -type PO PO
add mapped point y[4] y[4] -type PO PO
add mapped point y[3] y[3] -type PO PO
add mapped point y[2] y[2] -type PO PO
add mapped point y[1] y[1] -type PO PO
add mapped point y[0] y[0] -type PO PO
add mapped point scan_out scan_out -type PO PO

//inout ports




//Sequential Pins
add mapped point u_stage1/sum_a[0]/q u_stage1/sum_a_reg[0]/Q -type DFF DFF
add mapped point u_stage1/sum_a[1]/q u_stage1/sum_a_reg[1]/Q -type DFF DFF
add mapped point u_stage1/sum_a[2]/q u_stage1/sum_a_reg[2]/Q -type DFF DFF
add mapped point u_stage1/sum_a[3]/q u_stage1/sum_a_reg[3]/Q -type DFF DFF
add mapped point u_stage1/sum_a[4]/q u_stage1/sum_a_reg[4]/Q -type DFF DFF
add mapped point u_stage1/sum_a[5]/q u_stage1/sum_a_reg[5]/Q -type DFF DFF
add mapped point u_stage1/sum_a[6]/q u_stage1/sum_a_reg[6]/Q -type DFF DFF
add mapped point u_stage1/sum_a[7]/q u_stage1/sum_a_reg[7]/Q -type DFF DFF
add mapped point u_stage1/sum_a[8]/q u_stage1/sum_a_reg[8]/Q -type DFF DFF
add mapped point u_stage1/sum_b[0]/q u_stage1/sum_b_reg[0]/Q -type DFF DFF
add mapped point u_stage1/sum_b[1]/q u_stage1/sum_b_reg[1]/Q -type DFF DFF
add mapped point u_stage1/sum_b[2]/q u_stage1/sum_b_reg[2]/Q -type DFF DFF
add mapped point u_stage1/sum_b[3]/q u_stage1/sum_b_reg[3]/Q -type DFF DFF
add mapped point u_stage1/sum_b[4]/q u_stage1/sum_b_reg[4]/Q -type DFF DFF
add mapped point u_stage1/sum_b[5]/q u_stage1/sum_b_reg[5]/Q -type DFF DFF
add mapped point u_stage1/sum_b[6]/q u_stage1/sum_b_reg[6]/Q -type DFF DFF
add mapped point u_stage1/sum_b[7]/q u_stage1/sum_b_reg[7]/Q -type DFF DFF
add mapped point u_stage1/sum_b[8]/q u_stage1/sum_b_reg[8]/Q -type DFF DFF
add mapped point u_stage1/valid_out/q u_stage1/valid_out_reg/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[9]/q u_stage2/prod_b_out_reg[9]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[8]/q u_stage2/prod_b_out_reg[8]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[7]/q u_stage2/prod_b_out_reg[7]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[6]/q u_stage2/prod_b_out_reg[6]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[5]/q u_stage2/prod_b_out_reg[5]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[4]/q u_stage2/prod_b_out_reg[4]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[2]/q u_stage2/prod_b_out_reg[2]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[3]/q u_stage2/prod_b_out_reg[3]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[1]/q u_stage2/prod_b_out_reg[1]/Q -type DFF DFF
add mapped point u_stage2/valid_out/q u_stage2/valid_out_reg/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[8]/q u_stage2/sum_a_out_reg[8]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[5]/q u_stage2/sum_a_out_reg[5]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[0]/q u_stage2/prod_b_out_reg[0]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[0]/q u_stage2/sum_a_out_reg[0]/Q -type DFF DFF
add mapped point u_stage2/prod_b_out[10]/q u_stage2/prod_b_out_reg[10]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[1]/q u_stage2/sum_a_out_reg[1]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[2]/q u_stage2/sum_a_out_reg[2]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[7]/q u_stage2/sum_a_out_reg[7]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[3]/q u_stage2/sum_a_out_reg[3]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[6]/q u_stage2/sum_a_out_reg[6]/Q -type DFF DFF
add mapped point u_stage2/sum_a_out[4]/q u_stage2/sum_a_out_reg[4]/Q -type DFF DFF
add mapped point u_stage3/result[7]/q u_stage3/result_reg[7]/Q -type DFF DFF
add mapped point u_stage3/result[6]/q u_stage3/result_reg[6]/Q -type DFF DFF
add mapped point u_stage3/result[5]/q u_stage3/result_reg[5]/Q -type DFF DFF
add mapped point u_stage3/result[4]/q u_stage3/result_reg[4]/Q -type DFF DFF
add mapped point u_stage3/result[3]/q u_stage3/result_reg[3]/Q -type DFF DFF
add mapped point u_stage3/result[2]/q u_stage3/result_reg[2]/Q -type DFF DFF
add mapped point u_stage3/result[1]/q u_stage3/result_reg[1]/Q -type DFF DFF
add mapped point u_stage3/result[0]/q u_stage3/result_reg[0]/Q -type DFF DFF
add mapped point u_stage3/valid_out/q u_stage3/valid_out_reg/Q -type DFF DFF
add mapped point x_d3[4]/q x_d3_reg[4]/Q -type DFF DFF
add mapped point x_d3[7]/q x_d3_reg[7]/Q -type DFF DFF
add mapped point x_d3[6]/q x_d3_reg[6]/Q -type DFF DFF
add mapped point x_d3[1]/q x_d3_reg[1]/Q -type DFF DFF
add mapped point x_d3[2]/q x_d3_reg[2]/Q -type DFF DFF
add mapped point x_d3[3]/q x_d3_reg[3]/Q -type DFF DFF
add mapped point x_d3[5]/q x_d3_reg[5]/Q -type DFF DFF
add mapped point x_d1[4]/q x_d1_reg[4]/Q -type DFF DFF
add mapped point x_d1[0]/q x_d1_reg[0]/Q -type DFF DFF
add mapped point x_d1[3]/q x_d1_reg[3]/Q -type DFF DFF
add mapped point x_d1[2]/q x_d1_reg[2]/Q -type DFF DFF
add mapped point x_d1[1]/q x_d1_reg[1]/Q -type DFF DFF
add mapped point x_d3[0]/q x_d3_reg[0]/Q -type DFF DFF
add mapped point x_d1[6]/q x_d1_reg[6]/Q -type DFF DFF
add mapped point x_d1[7]/q x_d1_reg[7]/Q -type DFF DFF
add mapped point x_d2[0]/q x_d2_reg[0]/Q -type DFF DFF
add mapped point x_d2[1]/q x_d2_reg[1]/Q -type DFF DFF
add mapped point x_d2[2]/q x_d2_reg[2]/Q -type DFF DFF
add mapped point x_d1[5]/q x_d1_reg[5]/Q -type DFF DFF
add mapped point x_d2[4]/q x_d2_reg[4]/Q -type DFF DFF
add mapped point x_d2[5]/q x_d2_reg[5]/Q -type DFF DFF
add mapped point x_d2[6]/q x_d2_reg[6]/Q -type DFF DFF
add mapped point x_d2[7]/q x_d2_reg[7]/Q -type DFF DFF
add mapped point x_d2[3]/q x_d2_reg[3]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
