#!/bin/bash
# =============================================================================
# File   : fv/fir4/run_lec_synth.sh
# Purpose: Post-synthesis LEC — RTL vs Genus netlist (output/fir4_netlist.v)
#          Run this AFTER synthesis and BEFORE P&R to catch retiming /
#          arithmetic restructuring issues early.
# =============================================================================
cd "$(dirname "$0")"

mkdir -p reports

NETLIST="../../output/fir4_netlist.v"
if [ ! -f "$NETLIST" ]; then
    echo "ERROR: synthesis netlist not found: $NETLIST"
    echo "       Run Genus synthesis first."
    exit 1
fi

GUI=${GUI:-0}

echo "============================================================"
echo "  Post-synthesis LEC -- fir4 RTL vs Genus netlist"
echo "  Mode    : $([ $GUI -eq 1 ] && echo 'GUI' || echo 'batch')"
echo "  Golden  : ../../rtl/fir4.sv"
echo "  Revised : $NETLIST"
echo "============================================================"

PROJECT_DIR="$(cd ../.. && pwd)"
. "${PROJECT_DIR}/scripts/with_cadence.sh"

if [ $GUI -eq 1 ]; then
    TMP_DO="$(mktemp --suffix=.do)"
    trap 'rm -f "$TMP_DO"' EXIT
    grep -v '^exit -f[[:space:]]*$' run_lec_synth.do > "$TMP_DO"
    cadence_run "lec -xl -gui -dofile '$TMP_DO' -logfile reports/lec_synth.log"
    exit 0
fi

cadence_run "lec -xl -nogui -dofile run_lec_synth.do -logfile reports/lec_synth.log" \
    || true

RPT="reports/lec_synth.rpt"
if [ ! -f "$RPT" ]; then
    echo "ERROR: LEC report not produced: $RPT"
    exit 2
fi

echo ""
echo "============================================================"
echo "  Post-synth LEC Summary"
echo "============================================================"
grep -E "Compare Results:|Number of (EQ|NON-EQ|Aborted|Uncompared)" "$RPT" \
    || echo "  (no summary lines matched)"

PASS=$(awk '
    /Number of EQ compare points/       { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) eq=$i }
    /Number of NON-EQ compare points/   { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) ne=$i }
    /Number of Aborted compare points/  { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) ab=$i }
    /Number of Uncompared compare points/ { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) un=$i }
    END { if (eq > 0 && ne == 0 && ab == 0 && un == 0) print "PASS"; else print "FAIL" }
' "$RPT")

echo ""
if [ "$PASS" = "PASS" ]; then
    echo "  RESULT: POST-SYNTH LEC PASS"
    exit 0
else
    echo "  RESULT: POST-SYNTH LEC FAIL -- fix synthesis before P&R"
    exit 1
fi
