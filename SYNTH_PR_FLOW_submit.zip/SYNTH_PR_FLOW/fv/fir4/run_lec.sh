#!/bin/bash
# =============================================================================
# File   : fv/fir4/run_lec.sh
# Tool   : Cadence Conformal LEC (lec)
# Purpose: Drive logical-equivalence check between
#            golden  = rtl/fir4.sv
#            revised = innovus/output/fir4_final_netlist.v
# =============================================================================
# NOT `set -e`: Conformal exits non-zero on FAIL:INCOMPLETE (cosmetic).
cd "$(dirname "$0")"

mkdir -p reports

NETLIST="../../innovus/output/fir4_final_netlist.v"
if [ ! -f "$NETLIST" ]; then
    echo "ERROR: post-P&R netlist not found: $NETLIST"
    echo "       Run Innovus 06_signoff.tcl first."
    exit 1
fi

GUI=${GUI:-0}

echo "============================================================"
echo "  Conformal LEC -- fir4 RTL vs Final Netlist"
echo "  Mode    : $([ $GUI -eq 1 ] && echo 'GUI (interactive)' || echo 'batch')"
echo "  Golden  : ../../rtl/fir4.sv"
echo "  Revised : $NETLIST"
echo "  Output  : reports/lec_rtl_vs_final.{log,rpt}"
echo "============================================================"

PROJECT_DIR="$(cd ../.. && pwd)"
. "${PROJECT_DIR}/scripts/with_cadence.sh"

if [ $GUI -eq 1 ]; then
    TMP_DO="$(mktemp --suffix=.do)"
    trap 'rm -f "$TMP_DO"' EXIT
    grep -v '^exit -f[[:space:]]*$' run_lec.do > "$TMP_DO"
    cadence_run "lec -xl -gui -dofile '$TMP_DO' -logfile reports/lec_rtl_vs_final.log"
    exit 0
fi

cadence_run "lec -xl -nogui -dofile run_lec.do -logfile reports/lec_rtl_vs_final.log" \
    || true

RPT="reports/lec_rtl_vs_final.rpt"
if [ ! -f "$RPT" ]; then
    echo "ERROR: LEC report not produced: $RPT"
    exit 2
fi

echo ""
echo "============================================================"
echo "  LEC Summary"
echo "============================================================"
grep -E "Compare Results:|Number of (EQ|NON-EQ|Aborted|Uncompared)" "$RPT" \
    || echo "  (no summary lines matched -- review $RPT)"

PASS=$(awk '
    /Number of EQ compare points/       { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) eq=$i }
    /Number of NON-EQ compare points/   { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) ne=$i }
    /Number of Aborted compare points/  { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) ab=$i }
    /Number of Uncompared compare points/ { for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+$/) un=$i }
    END { if (eq > 0 && ne == 0 && ab == 0 && un == 0) print "PASS"; else print "FAIL" }
' "$RPT")

echo ""
if [ "$PASS" = "PASS" ]; then
    echo "  RESULT: LEC PASS (RTL = final netlist)"
    exit 0
else
    echo "  RESULT: LEC FAIL -- review $RPT"
    exit 1
fi
