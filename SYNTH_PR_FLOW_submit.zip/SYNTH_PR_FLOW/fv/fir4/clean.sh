#!/usr/bin/env bash
# fv/fir4/clean.sh — wipe ALL generated FV artefacts
# Keeps: run_lec.do, run_lec.sh, run_lec_synth.do, run_lec_synth.sh, clean.sh
set -e
cd "$(dirname "$0")"

DRY=0
[[ "${1:-}" == "--dry" ]] && DRY=1

nuke() {
    for p in "$@"; do
        for f in $p; do
            [[ -e "$f" || -L "$f" ]] || continue
            if (( DRY )); then echo "would remove: $f"
            else echo "removing: $f"; rm -rf "$f"; fi
        done
    done
}

# LEC reports + logs
nuke reports/*.log reports/*.rpt reports/*.log~

# Conformal working files
nuke lec.log lec.cmd lec.history lec_cmd*.log lec_cmd*.replay

# Genus-generated formal-mapping artefacts (regenerated each syn run)
nuke \
    fv_map.fv.json fv_map.map.do fv_map.user_hier.json \
    fv_map.v.gz fv_map.v \
    rtl_to_fv_map.do rtl_to_fv_map.do~ \
    read_libs.tcl

# Editor / tool backups
nuke *~ *.bak *.orig .*.swp .*.swo

# Recreate empty reports dir
if (( DRY == 0 )); then mkdir -p reports; fi

echo
if (( DRY )); then echo "Dry run."
else echo "fv/fir4 clean complete."; fi
