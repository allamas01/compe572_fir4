add_search_path . /ventura/apps/cadence/DDI/25.10/GENUS251/tools.lnx86/lib/tech -library -both
read_library -liberty -both \
    /home/ddelatoba2113/SYNTH_PR_FLOW/lib/slow_vdd1v0_basicCells.lib \
    /home/ddelatoba2113/SYNTH_PR_FLOW/lib/slow_vdd1v0_multibitsDFF.lib

