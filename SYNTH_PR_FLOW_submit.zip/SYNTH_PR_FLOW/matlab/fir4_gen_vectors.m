% =============================================================================
% fir4_gen_vectors.m -- Stimulus + expected-output generator
%
%   fir4_gen_vectors          write tb/stim_vectors.hex, tb/expected_vectors.hex
%   fir4_gen_vectors('plot')  also create figure fig_vectors
%
% 8 patterns, each followed by 8 zeros, concatenated: 716 samples.
% =============================================================================
function fir4_gen_vectors(varargin)
    do_plot = nargin > 0 && strcmpi(varargin{1}, 'plot');
    shift = 3;

    stim = {}; labels = {};
    stim{end+1} = [64 zeros(1, 19)];                labels{end+1} = 'Impulse';
    stim{end+1} = [zeros(1, 4) 127 * ones(1, 20)];  labels{end+1} = 'Step';
    stim{end+1} = -128:127;                         labels{end+1} = 'Ramp';

    n = 0:63;
    stim{end+1} = round(100 * sin(2*pi*n/32));      labels{end+1} = 'Sin low';
    stim{end+1} = round(100 * sin(2*pi*n/4));       labels{end+1} = 'Sin high';

    t = linspace(0, 1, 128);
    s = round(100 * sin(2*pi * (0.5 + 60*t) .* t));
    stim{end+1} = max(min(s, 127), -128);           labels{end+1} = 'Chirp';

    rng(42);
    stim{end+1} = randi([-128 127], 1, 64);         labels{end+1} = 'Random';

    stim{end+1} = [127 * ones(1, 8), -128 * ones(1, 8), repmat([127 -128], 1, 8)];
    labels{end+1} = 'Saturation';

    all_x = [];
    starts = zeros(1, numel(stim));
    for k = 1:numel(stim)
        starts(k) = numel(all_x) + 1;
        all_x = [all_x, stim{k}, zeros(1, 8)]; %#ok<AGROW>
    end
    all_y = fir4_rtl_model(all_x, shift);

    assert(numel(all_x) == 716, 'Expected 716 vectors, got %d', numel(all_x));

    here  = fileparts(mfilename('fullpath'));
    tbdir = fullfile(here, '..', 'tb');
    if ~exist(tbdir, 'dir'), mkdir(tbdir); end
    write_hex_signed(fullfile(tbdir, 'stim_vectors.hex'),     all_x, 8);
    write_hex_signed(fullfile(tbdir, 'expected_vectors.hex'), all_y, 11);

    fprintf('Wrote %d vectors to %s\n', numel(all_x), tbdir);
    for k = 1:numel(stim)
        fprintf('  %-10s start=%4d  length=%3d\n', labels{k}, starts(k), numel(stim{k}));
    end

    if do_plot
        figure('Name', 'fig_vectors', 'NumberTitle', 'off', 'Position', [100 100 1000 600]);
        subplot(2, 1, 1);
        plot(0:numel(all_x) - 1, all_x, 'Color', [0.4 0.4 0.4]);
        grid on; title('Stimulus (716 samples, 8 patterns)'); ylabel('x[n]');
        subplot(2, 1, 2);
        plot(0:numel(all_y) - 1, all_y, 'b');
        grid on; title('Expected output (RTL model)'); xlabel('sample'); ylabel('y[n]');
    end
end

function write_hex_signed(filename, data, nbits)
    fid = fopen(filename, 'w');
    assert(fid > 0, 'Cannot open %s for writing', filename);
    mask = 2^nbits - 1;
    fmt  = sprintf('%%0%dX\n', ceil(nbits / 4));
    for i = 1:length(data)
        val = data(i);
        if val < 0
            val = bitand(val + 2^nbits, mask);
        else
            val = bitand(val, mask);
        end
        fprintf(fid, fmt, val);
    end
    fclose(fid);
end
