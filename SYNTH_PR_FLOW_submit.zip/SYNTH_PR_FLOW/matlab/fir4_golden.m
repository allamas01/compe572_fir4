% =============================================================================
% fir4_golden.m -- Golden reference model for the fir4 filter
%
%   fir4_golden          print comparison tables
%   fir4_golden('plot')  also create the overlay figure (Name: fig_golden)
%
% Exact model : filter() with [1 3 3 1]/8 in floating point.
% RTL model   : fir4_rtl_model.m (floor after the final add).
% =============================================================================
function fir4_golden(varargin)
    do_plot = nargin > 0 && strcmpi(varargin{1}, 'plot');

    coeffs  = [1 3 3 1];
    nrm     = sum(coeffs);              % 8
    shift   = log2(nrm);                % 3
    b_exact = coeffs / nrm;             % [0.125 0.375 0.375 0.125]

    n_sin = 0:31;
    tests = struct( ...
        'name', {'Impulse (64)', 'Step (127)', 'Sinusoid (A=100, T=16)'}, ...
        'x',    {[64 zeros(1, 7)], 127 * ones(1, 12), round(100 * sin(2*pi*n_sin/16))});

    for k = 1:numel(tests)
        x       = tests(k).x;
        y_exact = filter(b_exact, 1, x);
        y_rtl   = fir4_rtl_model(x, shift);
        tests(k).y_exact = y_exact;
        tests(k).y_rtl   = y_rtl;
        print_table(tests(k).name, x, y_exact, y_rtl);
    end

    imp = tests(1).y_rtl(1:4);
    assert(isequal(imp, [8 24 24 8]), 'Impulse response should be [8 24 24 8]');
    assert(tests(2).y_rtl(end) == 127, 'Step response should converge to 127');
    fprintf('Self-check OK: impulse = [8 24 24 8], step -> 127\n');

    if do_plot
        figure('Name', 'fig_golden', 'NumberTitle', 'off', 'Position', [100 100 900 800]);
        for k = 1:numel(tests)
            subplot(numel(tests), 1, k);
            n = 0:numel(tests(k).x) - 1;
            plot(n, tests(k).y_exact, 'b-o', 'LineWidth', 1.5); hold on;
            stairs(n, tests(k).y_rtl, 'r-', 'LineWidth', 1.5);
            grid on;
            title(sprintf('%s: exact vs RTL (floor)', tests(k).name));
            xlabel('n'); ylabel('y[n]');
            legend('exact filter()', 'RTL model', 'Location', 'best');
        end
    end
end

function print_table(name, x, y_exact, y_rtl)
    fprintf('\n--- %s ---\n', name);
    fprintf('%4s %6s %10s %8s %8s\n', 'n', 'x[n]', 'exact', 'RTL', 'error');
    for n = 1:length(x)
        fprintf('%4d %6d %10.4f %8d %8.4f\n', n - 1, x(n), y_exact(n), y_rtl(n), ...
                y_exact(n) - y_rtl(n));
    end
end
