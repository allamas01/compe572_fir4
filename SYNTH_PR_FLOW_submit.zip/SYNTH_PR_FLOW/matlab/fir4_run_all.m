% =============================================================================
% fir4_run_all.m -- Master launcher
%
% Runs the golden model, the vector generator and the visualization suite,
% then saves every open figure as <figure Name>.pdf next to this file.
% =============================================================================
function fir4_run_all()
    here = fileparts(mfilename('fullpath'));
    addpath(here);
    close all;

    fprintf('===== [1/3] Golden Reference Model =====\n');
    fir4_golden('plot');

    fprintf('===== [2/3] Test Vector Generation =====\n');
    fir4_gen_vectors('plot');

    fprintf('===== [3/3] Visualization Suite =====\n');
    fir4_visualize();

    figs = findall(0, 'Type', 'figure');
    for i = 1:numel(figs)
        fname = get(figs(i), 'Name');
        if isempty(fname), fname = sprintf('fig_extra_%d', i); end
        exportgraphics(figs(i), fullfile(here, [fname '.pdf']), 'ContentType', 'vector');
        fprintf('Saved %s.pdf\n', fname);
    end
end
