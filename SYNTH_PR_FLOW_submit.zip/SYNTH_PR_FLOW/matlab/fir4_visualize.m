% =============================================================================
% fir4_visualize.m -- Six figures for the [1,3,3,1]/8 binomial low-pass
%
% Figure Names (used by fir4_run_all.m for the PDF file names):
%   fig1_freq_response, fig2_pole_zero, fig3_impulse,
%   fig4_chirp, fig5_spectrogram, fig6_quant_error
% =============================================================================
function fir4_visualize()
    b = [1 3 3 1] / 8; a = 1; Fs = 300e6;
    shift = 3;

    % ---- Figure 1: frequency response ----
    [H, w] = freqz(b, a, 1024);
    f = w / (2*pi) * Fs / 1e6;
    mag_db = 20 * log10(abs(H) + eps);
    idx_3dB = find(mag_db <= -3, 1, 'first');
    f_3dB = f(idx_3dB);

    figure('Name', 'fig1_freq_response', 'NumberTitle', 'off', 'Position', [100 100 900 700]);
    subplot(2, 1, 1);
    plot(f, mag_db, 'b', 'LineWidth', 2); hold on;
    yline(-3, 'r--', '-3 dB');
    plot(f_3dB, mag_db(idx_3dB), 'ro', 'MarkerFaceColor', 'r');
    text(f_3dB, mag_db(idx_3dB) - 6, sprintf(' f_{-3dB} = %.1f MHz', f_3dB));
    ylim([-80 5]); grid on;
    title('Magnitude Response -- [1,3,3,1]/8 Binomial Low-Pass');
    xlabel('Frequency (MHz)'); ylabel('|H| (dB)');
    subplot(2, 1, 2);
    plot(f, unwrap(angle(H)) * 180 / pi, 'b', 'LineWidth', 2); grid on;
    title('Phase Response (linear phase)');
    xlabel('Frequency (MHz)'); ylabel('Phase (deg)');

    % ---- Figure 2: pole-zero ----
    figure('Name', 'fig2_pole_zero', 'NumberTitle', 'off', 'Position', [100 100 600 600]);
    zplane(b, a);
    grid on;
    title('Pole-Zero Plot (triple zero at z = -1)');

    % ---- Figure 3: impulse response, exact vs RTL ----
    x_imp = [64 zeros(1, 11)];
    y_imp_exact = filter(b, a, x_imp);
    y_imp_rtl = fir4_rtl_model(x_imp, shift);
    figure('Name', 'fig3_impulse', 'NumberTitle', 'off', 'Position', [100 100 800 450]);
    stem(0:numel(x_imp) - 1, y_imp_exact, 'b', 'LineWidth', 1.5); hold on;
    stem(0:numel(x_imp) - 1, y_imp_rtl, 'r--', 'LineWidth', 1.5);
    grid on; xlabel('n'); ylabel('y[n]');
    title('Impulse Response (input = 64): exact vs RTL');
    legend('exact', 'RTL', 'Location', 'northeast');

    % ---- Figure 4: chirp test ----
    N_chirp = 256;
    t = linspace(0, 1, N_chirp);
    x_chirp = round(100 * sin(2*pi * (0.5 + 60*t) .* t));
    x_chirp = max(min(x_chirp, 127), -128);
    y_chirp = fir4_rtl_model(x_chirp, shift);
    figure('Name', 'fig4_chirp', 'NumberTitle', 'off', 'Position', [100 100 1000 450]);
    plot(0:N_chirp - 1, x_chirp, 'Color', [0.6 0.6 0.6]); hold on;
    plot(0:N_chirp - 1, y_chirp, 'b', 'LineWidth', 1.5);
    grid on; xlabel('n'); ylabel('amplitude');
    title('Chirp: low freqs pass, high freqs attenuated');
    legend('input', 'RTL output', 'Location', 'northeast');

    % ---- Figure 5: spectrogram, input vs output ----
    N_sp = 2048;
    t_sp = linspace(0, 1, N_sp);
    x_sp = round(100 * sin(2*pi * (0.5 + 0.5*N_sp/2*t_sp) .* t_sp));
    x_sp = max(min(x_sp, 127), -128);
    y_sp = fir4_rtl_model(x_sp, shift);
    figure('Name', 'fig5_spectrogram', 'NumberTitle', 'off', 'Position', [100 100 1000 700]);
    subplot(2, 1, 1);
    spectrogram(x_sp, 128, 120, 256, Fs, 'yaxis');
    title('Spectrogram: input chirp');
    subplot(2, 1, 2);
    spectrogram(y_sp, 128, 120, 256, Fs, 'yaxis');
    title('Spectrogram: filter output');

    % ---- Figure 6: quantization error (exact - RTL) ----
    rng(42);
    x_q = randi([-128 127], 1, 512);
    err = filter(b, a, x_q) - fir4_rtl_model(x_q, shift);
    figure('Name', 'fig6_quant_error', 'NumberTitle', 'off', 'Position', [100 100 900 700]);
    subplot(2, 1, 1);
    plot(0:numel(err) - 1, err, 'b'); grid on;
    title('Quantization error (exact - RTL), random input');
    xlabel('n'); ylabel('error (LSB)');
    subplot(2, 1, 2);
    histogram(err, 16); grid on;
    title(sprintf('Error distribution: min %.3f, max %.3f, mean %.3f', ...
                  min(err), max(err), mean(err)));
    xlabel('error (LSB)'); ylabel('count');
end
