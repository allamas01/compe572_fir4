% =============================================================================
% fir4_rtl_model.m -- Bit-accurate model of the fir4 RTL datapath
%
% Same order of operations as rtl/fir4.sv: pre-add, multiply-by-3,
% final add, then floor-divide by 2^shift (arithmetic right shift).
% Asserts every intermediate fits the register width used in the RTL.
% =============================================================================
function y = fir4_rtl_model(x, shift)
    if nargin < 2, shift = 3; end
    N = length(x);
    y = zeros(1, N);
    d = zeros(1, 4);                      % delay line, cleared like rst_b
    for n = 1:N
        d = [x(n) d(1:3)];                % d(1)=x[n] ... d(4)=x[n-3]
        sum_a  = d(1) + d(4);             % 9-bit signed
        sum_b  = d(2) + d(3);             % 9-bit signed
        prod_b = sum_b * 3;               % 11-bit signed
        y(n)   = floor((sum_a + prod_b) / 2^shift);   % 8-bit signed

        assert(sum_a  >= -256  && sum_a  <= 255,  'sum_a overflows 9 bits at n=%d', n);
        assert(sum_b  >= -256  && sum_b  <= 255,  'sum_b overflows 9 bits at n=%d', n);
        assert(prod_b >= -1024 && prod_b <= 1023, 'prod_b overflows 11 bits at n=%d', n);
        assert(y(n)   >= -128  && y(n)   <= 127,  'y overflows 8 bits at n=%d', n);
    end
end
