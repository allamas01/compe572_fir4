===============================================================================
  fir4 — Complete RTL-to-GDS Flow on gpdk045 (45 nm)
  Cadence Genus + Innovus + Xcelium + Conformal LEC
  COMPE572 Spring 2026, San Diego State University
===============================================================================


-------------------------------------------------------------------------------
  QUICK START
-------------------------------------------------------------------------------

  bash run_flow.sh

That's it. The script wraps every stage with:

    bash -l -c 'module load cadence_ece && <stage cmd>'

You do NOT need to load cadence_ece first. The module publishes
genus/innovus/xrun/lec as Apptainer shell functions (not PATH
binaries). Shell functions are not inherited by child processes, so
the load must happen inside each stage's bash process.


-------------------------------------------------------------------------------
  DESIGN
-------------------------------------------------------------------------------

  fir4 — 4-tap symmetric FIR low-pass filter
  Coefficients: [1, 3, 3, 1] / 8
  y[n] = (x[n] + x[n-3] + 3*(x[n-1] + x[n-2])) / 8

  Pipeline: 3 registered stages.  Latency: 3 clocks.  Target: 300 MHz.
  Input: 8-bit signed.  Output: 11-bit signed (sign-extended).
  Exact arithmetic (add first, then >>>3) — no pre-normalization truncation.

  MATLAB golden model generates stimulus + expected vectors for the
  self-checking testbench (716 vectors across 8 test patterns).


-------------------------------------------------------------------------------
  FLOW STAGES (10 stages, sequential)
-------------------------------------------------------------------------------

  Stage       Tool        Description
  ----------  ----------  -----------------------------------------------
  clean       bash        Remove all generated artifacts (clean.sh)
  matlab      MATLAB      Golden model + test vector generation
  rtl         Xcelium     RTL simulation with MATLAB vectors
  synth       Genus       Synthesis + DFT scan insertion
  lec_synth   Conformal   Post-synth LEC (RTL vs synthesis netlist)
  pnr         Innovus     Place-and-route (6 sub-stages)
  cdl         Innovus     CDL netlist export for LVS
  gls_func    Xcelium     Functional gate-level simulation
  gls_time    Xcelium     Timing GLS with post-P&R SDF back-annotation
  lec         Conformal   Post-P&R LEC (RTL vs final netlist)


-------------------------------------------------------------------------------
  RUN_FLOW.SH OPTIONS
-------------------------------------------------------------------------------

  Full flow (all 10 stages):
    bash run_flow.sh

  Front-end only (clean + MATLAB + RTL sim + synthesis + post-synth LEC):
    bash run_flow.sh --rtl-synth

  Skip cleanup:
    bash run_flow.sh --no-clean

  Skip LEC stages:
    bash run_flow.sh --skip-lec

  Run a single stage:
    bash run_flow.sh --only <stage>

    Valid stages: clean, matlab, rtl, synth, lec_synth, pnr, cdl,
                  gls_func, gls_time, lec

  Resume from a stage (runs that stage and all subsequent):
    bash run_flow.sh --from <stage>

  GUI mode (interactive tools with viewers):
    bash run_flow.sh --gui                  # all stages with GUI
    bash run_flow.sh --gui --only rtl       # SimVision waveforms
    bash run_flow.sh --gui --only synth     # Genus schematic viewer
    bash run_flow.sh --gui --only pnr       # Innovus layout viewer
    bash run_flow.sh --gui --only gls_func  # SimVision functional GLS
    bash run_flow.sh --gui --only gls_time  # SimVision timing GLS
    bash run_flow.sh --gui --only lec       # Conformal GUI
    bash run_flow.sh --gui --only lec_synth # post-synth LEC GUI
    bash run_flow.sh --gui --only matlab    # MATLAB desktop

  Timing margin override (default 100 ps):
    TIMING_MARGIN_PS=50 bash run_flow.sh

  Cadence module name override (default cadence_ece):
    MODULE_NAME=cadence bash run_flow.sh

  Help:
    bash run_flow.sh --help


-------------------------------------------------------------------------------
  RUNNING INDIVIDUAL STAGES MANUALLY
-------------------------------------------------------------------------------

  MATLAB golden model + test vectors:
    cd matlab && matlab -batch 'fir4_run_all' && cd ..

  RTL simulation:
    bash scripts/run_rtl_sim.sh
    GUI=1 bash scripts/run_rtl_sim.sh          # with SimVision

  Synthesis:
    genus -batch -f scripts/syn.tcl -log output/genus_fir4.log
    genus -f scripts/syn.tcl                   # with Genus GUI

  Post-synthesis LEC:
    bash fv/fir4/run_lec_synth.sh
    GUI=1 bash fv/fir4/run_lec_synth.sh        # with Conformal GUI

  Place-and-route (all 6 sub-stages):
    innovus -batch -files innovus/scripts/run_all.tcl \
            -log innovus/output/innovus_run_all.log
    innovus -files innovus/scripts/run_all.tcl  # with Innovus GUI

  CDL export:
    innovus -batch -files innovus/scripts/write_cdl.tcl \
            -log innovus/output/write_cdl.log

  Functional GLS:
    bash scripts/run_gls.sh
    GUI=1 bash scripts/run_gls.sh              # with SimVision

  Timing GLS (SDF back-annotation):
    TIMING=1 bash scripts/run_gls.sh
    TIMING=1 GUI=1 bash scripts/run_gls.sh     # with SimVision

  Post-P&R LEC:
    bash fv/fir4/run_lec.sh
    GUI=1 bash fv/fir4/run_lec.sh              # with Conformal GUI

  Cleanup:
    ./clean.sh                                 # delete everything
    ./clean.sh --dry                           # preview only


-------------------------------------------------------------------------------
  TIMING CLOSURE
-------------------------------------------------------------------------------

  Post-synthesis timing may show small violations (-10 to -50 ps WNS)
  on the stage 3 carry chain. Violations within TIMING_MARGIN_PS
  (default 100 ps) are treated as warnings — Innovus optDesign
  typically recovers 100-200 ps through cell upsizing, buffer insertion,
  and useful-skew CTS.

  Post-P&R signoff timing (Innovus RC extraction + report_timing) is
  the definitive result. Check:
    innovus/output/fir4_signoff_setup.rpt   # all paths MET, WNS > 0
    innovus/output/fir4_signoff_hold.rpt    # all paths MET, WNS > 0


-------------------------------------------------------------------------------
  LEC NOTES
-------------------------------------------------------------------------------

  Two LEC stages catch different classes of bugs:

  lec_synth (post-synthesis):
    Golden: rtl/fir4.sv
    Revised: output/fir4_netlist.v (Genus gate-level)
    Catches: retiming, arithmetic restructuring, sign-bit optimization

  lec (post-P&R):
    Golden: rtl/fir4.sv
    Revised: innovus/output/fir4_final_netlist.v (Innovus gate-level)
    Catches: P&R optimization, buffer removal, scan chain issues

  Both constrain DFT pins (scan_en=0, test_mode=0, scan_in=0) and
  ignore scan_out. The Conformal banner may say FAIL:INCOMPLETE due
  to unmapped scan PIs — this is cosmetic. The scripts parse the
  actual compare results: PASS requires EQ > 0, NON-EQ = 0.


-------------------------------------------------------------------------------
  GATE-LEVEL SIMULATION NOTES
-------------------------------------------------------------------------------

  Cell models: lib/slow_vdd1v0_basicCells.v (timing-aware, with specify
  blocks for SDF IOPATH + $setuphold annotation). Loaded with xrun -v
  flag (library mode) for proper SDF instance resolution.

  Timing GLS uses post-P&R SDF from innovus/output/fir4.sdf. The TB
  adds a 200 ps INPUT_DLY after each @(posedge clk) in TIMING mode to
  avoid setup violations at the testbench-DUT boundary (real inputs
  would arrive within the 0.67 ns SDC input delay constraint).

  SDF annotation warnings suppressed:
    -nowarn SDFINF   Instance-not-found (stale SDF mismatch)
    -nowarn SDFNSB   No-specify-block (combinational cells)
    -nowarn SDFNET   Non-existent timing check (REMOVAL vs $recovery)


-------------------------------------------------------------------------------
  MATLAB INTEGRATION
-------------------------------------------------------------------------------

  matlab/fir4_golden.m       Golden reference model (exact + truncated)
  matlab/fir4_gen_vectors.m  Stimulus + expected output vector generation
  matlab/fir4_visualize.m    6 publication-quality figures
  matlab/fir4_run_all.m      Master launcher (runs all three above)

  Test patterns (8 total, 716 samples):
    1. Impulse           5. High-freq sinusoid (attenuated)
    2. Step              6. Chirp (DC to Nyquist)
    3. Ramp              7. Random noise
    4. Low-freq sinusoid 8. Saturation corners

  Vectors written to:
    tb/stim_vectors.hex       8-bit signed input (hex)
    tb/expected_vectors.hex   11-bit signed expected output (hex)


-------------------------------------------------------------------------------
  DIRECTORY LAYOUT
-------------------------------------------------------------------------------

  rtl/                 SystemVerilog RTL source (fir4.sv)
  tb/                  Testbench (tb_fir4.sv) + MATLAB hex vectors
  constraints/         SDC timing constraints (fir4.sdc)
  scripts/             Genus synthesis + simulation scripts
  innovus/scripts/     Innovus P&R stage scripts (01-06 + run_all)
  innovus/output/      Innovus checkpoints + reports + handoff files
  fv/fir4/             Conformal LEC dofiles + shell drivers
  fv/fir4/reports/     LEC reports and logs
  matlab/              MATLAB golden model + visualization
  lib/                 Liberty (.lib) + Verilog cell models (.v)
  lef/                 Technology + macro LEF, GDSII stream map
  captable/            Pre-route capacitance table
  QRC_Tech/            Post-route QRC tech file (gpdk045.tch)
  output/              Genus synthesis outputs + simulation logs
  gds/                 Final GDS stream
  cdl/                 Flat CDL netlist for LVS
  pvs/                 Physical verification scripts + results


-------------------------------------------------------------------------------
  KEY OUTPUT FILES
-------------------------------------------------------------------------------

  Synthesis (output/):
    fir4_netlist.v       Gate-level netlist (input to Innovus)
    fir4_out.sdc         Back-annotated SDC (input to Innovus MMMC)
    fir4_scan.def        Scan chain DEF (input to Innovus)
    fir4_timing.rpt      Pre-P&R timing (10 worst paths)
    fir4_area.rpt        Cell area breakdown
    fir4_power.rpt       Power estimate by hierarchy
    fir4_gates.rpt       Gate count summary
    fir4_qor.rpt         Quality of results

  Place-and-route (innovus/output/):
    fir4_final_netlist.v    Final gate-level netlist (GLS + LEC + LVS)
    fir4.sdf                Post-route SDF (timing GLS)
    fir4.spef               Post-route parasitics (external STA)
    fir4_final.def           Floorplan + routing DEF
    fir4_signoff_setup.rpt  Signoff setup timing
    fir4_signoff_hold.rpt   Signoff hold timing

  GDS (gds/):
    fir4.gds             Layout stream (DRC/LVS)


-------------------------------------------------------------------------------
  CLEANUP
-------------------------------------------------------------------------------

  ./clean.sh removes ALL generated artifacts. Source files are preserved:
    rtl/*.sv, tb/tb_*.sv, constraints/*.sdc, scripts/*, innovus/scripts/*,
    fv/fir4/*.do, fv/fir4/*.sh, matlab/*.m, lib/*, lef/*, captable/*,
    QRC_Tech/*, run_flow.sh, clean.sh, README.txt, ECE_GUIDE.html

  Preview what would be deleted:
    ./clean.sh --dry


===============================================================================
