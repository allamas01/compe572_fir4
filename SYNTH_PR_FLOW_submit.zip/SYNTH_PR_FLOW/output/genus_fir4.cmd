# Cadence Genus(TM) Synthesis Solution, Version 25.10-p002_1, built Apr 17 2025 15:35:38

# Date: Sat Oct 10 20:09:06 2026
# Host: volta (x86_64 w/Linux 5.4.0-216-generic) (24cores*96cpus*2physical cpus*Intel(R) Xeon(R) Gold 6248R CPU @ 3.00GHz 36608KB)
# OS:   Rocky Linux 8.10 (Green Obsidian)

source scripts/syn.tcl
