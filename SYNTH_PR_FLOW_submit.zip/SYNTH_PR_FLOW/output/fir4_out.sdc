# ####################################################################

#  Created by Genus(TM) Synthesis Solution 25.10-p002_1 on Sat Oct 10 20:09:43 PDT 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design fir4

set_case_analysis 0 [get_ports test_mode]
set_case_analysis 0 [get_ports scan_en]
create_clock -name "clk" -period 3.333 -waveform {0.0 1.667} [get_ports clk]
set_clock_transition 0.05 [get_clocks clk]
set_dont_touch_network [get_clocks clk]
set_load -pin_load 0.005 [get_ports valid_out]
set_load -pin_load 0.005 [get_ports {y[10]}]
set_load -pin_load 0.005 [get_ports {y[9]}]
set_load -pin_load 0.005 [get_ports {y[8]}]
set_load -pin_load 0.005 [get_ports {y[7]}]
set_load -pin_load 0.005 [get_ports {y[6]}]
set_load -pin_load 0.005 [get_ports {y[5]}]
set_load -pin_load 0.005 [get_ports {y[4]}]
set_load -pin_load 0.005 [get_ports {y[3]}]
set_load -pin_load 0.005 [get_ports {y[2]}]
set_load -pin_load 0.005 [get_ports {y[1]}]
set_load -pin_load 0.005 [get_ports {y[0]}]
set_load -pin_load 0.005 [get_ports scan_out]
set_false_path -from [list \
  [get_ports rst_b]  \
  [get_ports scan_en]  \
  [get_ports test_mode]  \
  [get_ports scan_in] ]
set_false_path -to [get_ports scan_out]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay -max 0.7 [get_ports rst_b]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports rst_b]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports valid_in]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports valid_in]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[7]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[6]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[5]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[4]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {x[0]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[7]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[6]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[5]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[4]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[3]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[2]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[1]}]
set_input_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {x[0]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[10]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[9]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[8]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[7]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[6]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[5]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[4]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports {y[0]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[10]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[9]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[8]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[7]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[6]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[5]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[4]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[3]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[2]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[1]}]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports {y[0]}]
set_output_delay -clock [get_clocks clk] -add_delay -max 0.67 [get_ports valid_out]
set_output_delay -clock [get_clocks clk] -add_delay -min 0.05 [get_ports valid_out]
set_max_fanout 20.000 [current_design]
set_max_transition 0.2 [current_design]
set_dont_touch [get_cells rm_assigns_buf_y_9]
set_dont_touch [get_cells rm_assigns_buf_y_8]
set_dont_touch [get_cells rm_assigns_buf_y_7]
set_clock_uncertainty -setup 0.05 [get_clocks clk]
set_clock_uncertainty -hold 0.03 [get_clocks clk]
