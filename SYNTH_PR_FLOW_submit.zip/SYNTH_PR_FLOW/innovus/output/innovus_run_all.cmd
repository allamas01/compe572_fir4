#######################################################
#                                                     
#  Innovus Command Logging File                     
#  Created on Sat Oct 10 20:10:08 2026                
#                                                     
#######################################################

#@(#)CDS: Innovus v25.10-p002_1 (64bit) 04/23/2025 12:43 (Linux 4.18.0-305.el8.x86_64)
#@(#)CDS: NanoRoute 25.10-p002_1 NR250317-0405/25_10-UB (database version 18.20.663) {superthreading v2.20}
#@(#)CDS: AAE 25.10-b008 (64bit) 04/23/2025 (Linux 4.18.0-305.el8.x86_64)
#@(#)CDS: CTE 25.10-b014_1 () Mar 28 2025 03:11:49 ( )
#@(#)CDS: SYNTECH 25.10-b006_1 () Mar 13 2025 03:32:26 ( )
#@(#)CDS: CPE v25.10-b011
#@(#)CDS: IQuantus/TQuantus 24.1.0-s201 (64bit) Thu Mar 20 10:21:58 PDT 2025 (Linux 4.18.0-305.el8.x86_64)

set_global _enable_mmmc_by_default_flow      $CTE::mmmc_default
suppressMessage ENCEXT-2799
getVersion
define_proc_arguments ViaFillQor -info {This procedure extracts Viafill details from innovus db} -define_args {
        {-window "window coordinates" "" list optional}
        {-window_size "window size in microns" "" string optional}
    
    }
define_proc_arguments ProcessFills -info {This procedure processes Fill types} -define_args {
    {-fillInfo "Design Fill data" "" list required}
				{-csvName "File path for Fill Data csv file" "Path of CSV file" string required}
				{-selectFill "type of fill to be selected in session" "list of BRIDGE/EXTENSION/STAMP/FLOATING" list required}
    {-output_data "Boolean Flag to output Fill Data for further processing" "" string required}
}
define_proc_arguments FillQor -info {This procedure extracts fill details from innovus db} -define_args {
    {-layers "Fills Cleanup on which all layers" "list of Metal/Routing layers" list optional}
				{-selectFill "type of fill to be selected in session" "list of BRIDGE/EXTENSION/STAMP/FLOATING" list optional}
				{-outData "Boolean Flag to output Fill Data for further processing" "" boolean optional}
    {-outDataFile "File path for Fill Data csv file" "Path of CSV file" string optional}
}
define_proc_arguments ProcessFills_fast -info {This procedure processes Fill types} -define_args {
    {-fillInfo "Design Fill data" "" list required}
				{-csvName "File path for Fill Data csv file" "Path of CSV file" string required}
				{-selectFill "type of fill to be selected in session" "list of BRIDGE/EXTENSION/STAMP/FLOATING" list required}
    {-output_data "Boolean Flag to output Fill Data for further processing" "" string required}
}
define_proc_arguments FillQor_fast -info {This procedure extracts fill details from innovus db} -define_args {
    {-layers "Fills Cleanup on which all layers" "list of Metal/Routing layers" list optional}
				{-selectFill "type of fill to be selected in session" "list of BRIDGE/EXTENSION/STAMP/FLOATING" list optional}
				{-outData "Boolean Flag to output Fill Data for further processing" "" boolean optional}
    {-outDataFile "File path for Fill Data csv file" "Path of CSV file" string optional}
}
define_proc_arguments ProcessFills_fast_stampOnly -info {This procedure processes Fill types} -define_args {
    {-fillInfo "Design Fill data" "" list required}
	
}
define_proc_arguments FillQor_fast_stampOnly -info {This procedure extracts fill details from innovus db} -define_args {
    {-layers "Fills Cleanup on which all layers" "list of Metal/Routing layers" list optional}
}
set init_lef_file {/home/ddelatoba2113/SYNTH_PR_FLOW/lef/gsclib045_tech.lef /home/ddelatoba2113/SYNTH_PR_FLOW/lef/gsclib045_macro.lef}
set init_mmmc_file /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/scripts/mmmc.tcl
set init_verilog /home/ddelatoba2113/SYNTH_PR_FLOW/output/fir4_netlist.v
set init_top_cell fir4
set init_pwr_net VDD
set init_gnd_net VSS
setDesignMode -process 45
init_design
defIn /home/ddelatoba2113/SYNTH_PR_FLOW/output/fir4_scan.def
checkTimingLibrary
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_init.enc
floorPlan -site CoreSite -coreMarginsBy die -r 1.0 0.70 2.0 2.0 2.0 2.0
setPinAssignMode -pinEditInBatch true
editPin -pin {clk rst_b valid_in} -side LEFT -layer 3 -spreadType range -snap TRACK -pinWidth 0.14 -pinDepth 2.50 -start {0.0 10.8775} -end {0.0 32.6325}
editPin -pin {{x[0]} {x[1]} {x[2]} {x[3]} {x[4]} {x[5]} {x[6]} {x[7]}} -side TOP -layer 4 -spreadType range -snap TRACK -pinWidth 0.14 -pinDepth 2.50 -start {4.42 43.51} -end {17.68 43.51}
editPin -pin {valid_out {y[0]} {y[1]} {y[2]} {y[3]} {y[4]} {y[5]} {y[6]} {y[7]} {y[8]} {y[9]} {y[10]}} -side RIGHT -layer 3 -spreadType range -snap TRACK -pinWidth 0.14 -pinDepth 2.50 -start {44.2 10.8775} -end {44.2 32.6325}
editPin -pin {scan_en test_mode scan_in scan_out} -side BOTTOM -layer 4 -spreadType range -snap TRACK -pinWidth 0.14 -pinDepth 2.50 -start {4.42 0.0} -end {17.68 0.0}
setPinAssignMode -pinEditInBatch false
addRing -nets {VDD VSS} -type core_rings -layer_top Metal3 -layer_bottom Metal3 -layer_left Metal4 -layer_right Metal4 -width 0.4 -spacing 0.2 -offset 0.3 -center 0
addStripe -nets {VDD VSS} -layer Metal4 -direction vertical -width 0.4 -spacing 0.2 -set_to_set_distance 8.0
sroute -nets {VDD VSS} -connect {corePin padPin padRing floatingStripe} -layerChangeRange {Metal1 Metal5}
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_floorplan.enc
setPlaceMode -timingDriven true -congEffort medium -checkCutSpacing true
place_design
setOptMode -effortLevel medium
optDesign -preCTS
report_timing -max_paths 5 > ${INV_OUT}/${DESIGN_NAME}_place_timing.rpt
checkPlace > /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_place_check.rpt
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_place.enc
create_ccopt_clock_tree_spec
set_ccopt_property buffer_cells {CLKBUFX2 CLKBUFX4 CLKBUFX8}
set_ccopt_property inverter_cells {CLKINVX2 CLKINVX4}
set_ccopt_property target_skew 0.050
set_ccopt_property target_max_trans 0.100
clock_opt_design
setOptMode -holdTargetSlack 0.0 -setupTargetSlack 0.0 -effortLevel medium
optDesign -postCTS
optDesign -postCTS -hold
report_timing -max_paths 10 > ${INV_OUT}/${DESIGN_NAME}_cts_timing.rpt
report_clock_timing -type summary > ${INV_OUT}/${DESIGN_NAME}_cts_skew.rpt
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_cts.enc
getAnalysisMode -socv -quiet
setNanoRouteMode -route_with_timing_driven true
getAnalysisMode -socv -quiet
setNanoRouteMode -route_with_si_driven true
getAnalysisMode -socv -quiet
setNanoRouteMode -route_top_routing_layer 10
getAnalysisMode -socv -quiet
setNanoRouteMode -route_bottom_routing_layer 1
routeDesign
setAnalysisMode -analysisType onChipVariation
setOptMode -holdTargetSlack 0.0 -setupTargetSlack 0.0 -effortLevel high
optDesign -postRoute
optDesign -postRoute -hold
addFiller -cell {FILL64 FILL32 FILL16 FILL8 FILL4 FILL2 FILL1} -prefix FILLER
verifyConnectivity -type all > /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_connectivity.rpt
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_route.enc
setExtractRCMode -engine postRoute -effortLevel medium -coupled true
extractRC
report_timing -late  -view view_setup -max_paths 20 \
    > ${INV_OUT}/${DESIGN_NAME}_signoff_setup.rpt
report_timing -early -view view_hold  -max_paths 20 \
    > ${INV_OUT}/${DESIGN_NAME}_signoff_hold.rpt
write_sdf -min_view view_hold -max_view view_setup -typ_view view_setup \
    -target_application verilog -interconn all \
    -setuphold split -recrem split -nonegchecks \
    ${INV_OUT}/${DESIGN_NAME}.sdf
rcOut -spef /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4.spef
streamOut /home/ddelatoba2113/SYNTH_PR_FLOW/gds/fir4.gds -libName fir4_lib -structureName fir4 -units 1000 -mode ALL -mapFile /home/ddelatoba2113/SYNTH_PR_FLOW/lef/gsclib045_stream.map
saveNetlist /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_final_netlist.v
saveDesign /home/ddelatoba2113/SYNTH_PR_FLOW/innovus/output/fir4_signoff.enc
