# =============================================================================
# 03_place.tcl -- Timing-driven placement
# Output checkpoint: innovus/output/fir4_place.enc
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set INV_OUT     ${PROJECT_DIR}/innovus/output
set DESIGN_NAME "fir4"

if {[catch {dbGet top.name} top] || $top ne ${DESIGN_NAME}} {
    restoreDesign ${INV_OUT}/${DESIGN_NAME}_floorplan.enc ${DESIGN_NAME}
}

setPlaceMode \
    -timingDriven    true   \
    -congEffort      medium \
    -checkCutSpacing true

place_design

# Pre-CTS optimization (medium effort is enough for a block this small)
setOptMode -effortLevel medium
optDesign -preCTS

report_timing -max_paths 5 > ${INV_OUT}/${DESIGN_NAME}_place_timing.rpt
checkPlace                 > ${INV_OUT}/${DESIGN_NAME}_place_check.rpt
saveDesign ${INV_OUT}/${DESIGN_NAME}_place.enc
