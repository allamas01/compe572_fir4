# =============================================================================
# 05_route.tcl -- Detail routing and post-route optimization
# Output checkpoint: innovus/output/fir4_route.enc
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set INV_OUT     ${PROJECT_DIR}/innovus/output
set DESIGN_NAME "fir4"

if {[catch {dbGet top.name} top] || $top ne ${DESIGN_NAME}} {
    restoreDesign ${INV_OUT}/${DESIGN_NAME}_cts.enc ${DESIGN_NAME}
}

# Timing- and SI-driven routing, Metal1..Metal10 (Metal11 is reserved)
set_db route_design_with_timing_driven true
set_db route_design_with_si_driven     true
set_db route_design_top_routing_layer    10
set_db route_design_bottom_routing_layer 1

routeDesign

# Post-route optimization with OCV (needed when SI-driven routing is on)
setAnalysisMode -analysisType onChipVariation
setOptMode -holdTargetSlack 0.0 -setupTargetSlack 0.0 -effortLevel high
optDesign -postRoute
optDesign -postRoute -hold

# Fillers for DRC compliance
addFiller -cell {FILL64 FILL32 FILL16 FILL8 FILL4 FILL2 FILL1} -prefix FILLER

# DRC, connectivity, antenna: all should report zero violations
verifyGeometry -error 1000 -report ${INV_OUT}/${DESIGN_NAME}_drc.rpt
verifyConnectivity -type all > ${INV_OUT}/${DESIGN_NAME}_connectivity.rpt
verify_process_antenna -report ${INV_OUT}/${DESIGN_NAME}_antenna.rpt -error 1000

saveDesign ${INV_OUT}/${DESIGN_NAME}_route.enc
