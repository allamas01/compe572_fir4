# =============================================================================
# write_cdl.tcl -- Export flat CDL netlist (cdl/fir4.cdl) for LVS  (Step 26)
#   innovus -batch -files innovus/scripts/write_cdl.tcl \
#           -log innovus/output/write_cdl.log
#
# Follows the guide (restoreDesign + saveNetlist -format cdl -includePhysicalCells
# -flat). This Innovus release (25.10) rejects those two forms, so each is
# wrapped: if the guide's command errors, an equivalent is used instead
# (Verilog with PG pins + fillers, converted to CDL with LEF pin order).
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set INV_OUT     ${PROJECT_DIR}/innovus/output
set CDL_DIR     ${PROJECT_DIR}/cdl
set LEF_DIR     ${PROJECT_DIR}/lef
set DESIGN_NAME "fir4"
file mkdir $CDL_DIR

# Guide form first; 25.10 wants the .enc.dat session directory
if {[catch {restoreDesign ${INV_OUT}/${DESIGN_NAME}_signoff.enc ${DESIGN_NAME}}]} {
    restoreDesign ${INV_OUT}/${DESIGN_NAME}_signoff.enc.dat ${DESIGN_NAME}
}

# Guide form: flat, with filler cells (they are in the layout, so LVS needs them)
if {[catch {
    saveNetlist \
        -format         cdl \
        -includePhysicalCells \
        -flat \
        ${CDL_DIR}/${DESIGN_NAME}.cdl
} err]} {
    puts "write_cdl: 'saveNetlist -format cdl' not supported here"
    puts "write_cdl: falling back to Verilog (+PG, +fillers) -> CDL conversion"

    set VLOG ${INV_OUT}/${DESIGN_NAME}_lvs.v
    saveNetlist $VLOG -flat -includePowerGround -includePhysicalInst -excludeLeafCell

    # --- cell pin order from the LEF ---
    array set PINS {}
    foreach lef [list ${LEF_DIR}/gsclib045_macro.lef ${LEF_DIR}/gsclib045_multibitsDFF.lef] {
        set fh [open $lef r]
        set cur ""
        while {[gets $fh line] >= 0} {
            set t [split [string trim $line] " "]
            set k [lindex $t 0]
            if {$k eq "MACRO"} {
                set cur [lindex $t 1]
                set PINS($cur) {}
            } elseif {$k eq "PIN" && $cur ne ""} {
                lappend PINS($cur) [lindex $t 1]
            } elseif {$k eq "END" && [lindex $t 1] eq $cur} {
                set cur ""
            }
        }
        close $fh
    }

    # --- read Verilog, strip comments ---
    set fh [open $VLOG r]
    set txt [read $fh]
    close $fh
    regsub -all {/\*.*?\*/} $txt "" txt
    regsub -all {//[^\n]*}  $txt "" txt

    # --- port list (expand buses to bit names) ---
    regexp "module\\s+${DESIGN_NAME}\\s*\\((\[^)\]*)\\)\\s*;" $txt -> plist
    array set BUS {}
    foreach {m hi lo nm} [regexp -all -inline {(?:input|output|inout)\s*\[(\d+):(\d+)\]\s*(\w+)\s*;} $txt] {
        set BUS($nm) [list $hi $lo]
    }
    set ports {}
    foreach p [split $plist ","] {
        set p [string trimleft [string trim $p] "\\"]
        if {[info exists BUS($p)]} {
            lassign $BUS($p) hi lo
            for {set i $hi} {$i >= $lo} {incr i -1} { lappend ports "${p}\[$i\]" }
        } else {
            lappend ports $p
        }
    }
    foreach pg {VDD VSS} { if {[lsearch -exact $ports $pg] < 0} { lappend ports $pg } }

    # --- instances ---
    set fo [open ${CDL_DIR}/${DESIGN_NAME}.cdl w]
    puts $fo "* CDL netlist of ${DESIGN_NAME} (flat, converted from Innovus Verilog)"
    puts $fo ".SUBCKT ${DESIGN_NAME} [join $ports { }]"
    set n 0
    set re {(?:^|\n)\s*(\w+)\s+(\\\S+|\w+)\s*\(([^;]*?)\)\s*;}
    set pos 0
    while {[regexp -start $pos -indices $re $txt all c i b]} {
        set cell [string range $txt {*}$c]
        set iname [string trimleft [string trim [string range $txt {*}$i]] "\\"]
        set conns [string range $txt {*}$b]
        set pos [expr {[lindex $all 1] + 1}]
        if {![info exists PINS($cell)]} { continue }   ;# module/wire/etc.
        array unset NET
        foreach {m pin net} [regexp -all -inline {\.(\w+)\s*\(\s*([^()]*?)\s*\)} $conns] {
            set NET($pin) [string trimleft [string trim $net] "\\"]
        }
        set args {}
        foreach pin $PINS($cell) {
            if {[info exists NET($pin)] && $NET($pin) ne ""} {
                lappend args $NET($pin)
            } elseif {$pin eq "VDD" || $pin eq "VSS"} {
                lappend args $pin
            } else {
                lappend args "NC_${n}_${pin}"
            }
        }
        puts $fo "X${iname} [join $args { }] $cell"
        incr n
    }
    puts $fo ".ENDS ${DESIGN_NAME}"
    close $fo
    puts "write_cdl: wrote $n instances to ${CDL_DIR}/${DESIGN_NAME}.cdl"
}
