# =============================================================================
# 06_signoff.tcl -- RC extraction, timing reports, output generation
# Output checkpoint: innovus/output/fir4_signoff.enc
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set INV_OUT     ${PROJECT_DIR}/innovus/output
set GDS_DIR     ${PROJECT_DIR}/gds
set LEF_DIR     ${PROJECT_DIR}/lef
set DESIGN_NAME "fir4"
file mkdir $GDS_DIR

if {[catch {dbGet top.name} top] || $top ne ${DESIGN_NAME}} {
    restoreDesign ${INV_OUT}/${DESIGN_NAME}_route.enc ${DESIGN_NAME}
}

# RC extraction with the post-route engine (Quantus)
setExtractRCMode -engine postRoute -effortLevel medium -coupled true
extractRC

# Signoff timing: setup on the slow view, hold on the fast view
report_timing -late  -view view_setup -max_paths 20 \
    > ${INV_OUT}/${DESIGN_NAME}_signoff_setup.rpt
report_timing -early -view view_hold  -max_paths 20 \
    > ${INV_OUT}/${DESIGN_NAME}_signoff_hold.rpt

# SDF for timing gate-level simulation (min and max views)
write_sdf -min_view view_hold -max_view view_setup -typ_view view_setup \
    -target_application verilog -interconn all \
    -setuphold split -recrem split -nonegchecks \
    ${INV_OUT}/${DESIGN_NAME}.sdf

# SPEF (external STA), GDS (DRC/LVS)
rcOut -spef ${INV_OUT}/${DESIGN_NAME}.spef
streamOut ${GDS_DIR}/${DESIGN_NAME}.gds -libName ${DESIGN_NAME}_lib \
    -structureName ${DESIGN_NAME} -units 1000 -mode ALL \
    -mapFile ${LEF_DIR}/gsclib045_stream.map

# Final netlist with no assign statements
catch { set_db / .remove_assigns true }
catch { remove_assigns_without_optimization }
saveNetlist ${INV_OUT}/${DESIGN_NAME}_final_netlist.v
saveDesign ${INV_OUT}/${DESIGN_NAME}_signoff.enc
