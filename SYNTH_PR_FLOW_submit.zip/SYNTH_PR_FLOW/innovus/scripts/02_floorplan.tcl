# =============================================================================
# 02_floorplan.tcl -- Floorplan, pin placement, power planning
# Output checkpoint: innovus/output/fir4_floorplan.enc
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set INV_OUT     ${PROJECT_DIR}/innovus/output
set DESIGN_NAME "fir4"

if {[catch {dbGet top.name} top] || $top ne ${DESIGN_NAME}} {
    restoreDesign ${INV_OUT}/${DESIGN_NAME}_init.enc ${DESIGN_NAME}
}

# Square die, 70% utilization, 2 um margins
floorPlan -site CoreSite -coreMarginsBy die \
    -r 1.0 0.70 2.0 2.0 2.0 2.0

# Die size, used to put pins in the 1/4 zone of each edge
# (keeps them away from the Metal4 power stripe down the middle)
set die   [lindex [dbGet top.fPlan.box] 0]
set DX_LO [lindex $die 0]
set DY_LO [lindex $die 1]
set DX_HI [lindex $die 2]
set DY_HI [lindex $die 3]
set W     [expr {$DX_HI - $DX_LO}]
set H     [expr {$DY_HI - $DY_LO}]

set LEFT_PINS   {clk rst_b valid_in}
set TOP_PINS    [list]
for {set i 0} {$i < 8} {incr i} { lappend TOP_PINS "x\[$i\]" }
set RIGHT_PINS  [list valid_out]
for {set i 0} {$i < 11} {incr i} { lappend RIGHT_PINS "y\[$i\]" }
set BOTTOM_PINS {scan_en test_mode scan_in scan_out}

# Pin placement: LEFT (clk/rst/valid_in), TOP (x), RIGHT (y/valid_out), BOTTOM (DFT)
setPinAssignMode -pinEditInBatch true
editPin -pin $LEFT_PINS -side LEFT -layer 3 -spreadType range \
    -snap TRACK -pinWidth 0.14 -pinDepth 2.50 \
    -start [list $DX_LO [expr {$DY_LO + $H*0.25}]] \
    -end   [list $DX_LO [expr {$DY_LO + $H*0.75}]]
editPin -pin $TOP_PINS -side TOP -layer 4 -spreadType range \
    -snap TRACK -pinWidth 0.14 -pinDepth 2.50 \
    -start [list [expr {$DX_LO + $W*0.10}] $DY_HI] \
    -end   [list [expr {$DX_LO + $W*0.40}] $DY_HI]
editPin -pin $RIGHT_PINS -side RIGHT -layer 3 -spreadType range \
    -snap TRACK -pinWidth 0.14 -pinDepth 2.50 \
    -start [list $DX_HI [expr {$DY_LO + $H*0.25}]] \
    -end   [list $DX_HI [expr {$DY_LO + $H*0.75}]]
editPin -pin $BOTTOM_PINS -side BOTTOM -layer 4 -spreadType range \
    -snap TRACK -pinWidth 0.14 -pinDepth 2.50 \
    -start [list [expr {$DX_LO + $W*0.10}] $DY_LO] \
    -end   [list [expr {$DX_LO + $W*0.40}] $DY_LO]
setPinAssignMode -pinEditInBatch false

# Power ring: Metal3 horizontal, Metal4 vertical
addRing -nets {VDD VSS} -type core_rings \
    -layer_top Metal3 -layer_bottom Metal3 \
    -layer_left Metal4 -layer_right Metal4 \
    -width 0.4 -spacing 0.2 -offset 0.3 -center 0

# Power stripes: Metal4 vertical
addStripe -nets {VDD VSS} -layer Metal4 -direction vertical \
    -width 0.4 -spacing 0.2 -set_to_set_distance 8.0

# Connect stripes and standard-cell rails to the ring
sroute -nets {VDD VSS} \
    -connect {corePin padPin padRing floatingStripe} \
    -layerChangeRange {Metal1 Metal5}

saveDesign ${INV_OUT}/${DESIGN_NAME}_floorplan.enc
