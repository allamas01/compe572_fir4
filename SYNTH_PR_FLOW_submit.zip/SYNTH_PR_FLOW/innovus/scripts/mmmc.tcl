# =============================================================================
# mmmc.tcl -- Multi-Mode Multi-Corner setup
# Read by init_design through $init_mmmc_file (01_init.tcl). Do not source it
# by hand. Pure MMMC-1 style: no create_timing_condition (TCLCMD-992).
# =============================================================================

set PROJECT_DIR [file normalize [file join [file dirname [info script]] ../..]]
set LIB_DIR     ${PROJECT_DIR}/lib
set SYN_OUT     ${PROJECT_DIR}/output
set DESIGN_NAME "fir4"
set QRC_TECH    ${PROJECT_DIR}/QRC_Tech/gpdk045.tch
set CAP_TABLE   ${PROJECT_DIR}/captable/cln28hpl_1p10m+alrdl_5x2yu2yz_typical.capTbl

# Library sets: slow corner for setup, fast corner for hold
create_library_set -name libs_slow -timing [list \
    ${LIB_DIR}/slow_vdd1v0_basicCells.lib   \
    ${LIB_DIR}/slow_vdd1v0_multibitsDFF.lib ]

create_library_set -name libs_fast -timing [list \
    ${LIB_DIR}/fast_vdd1v0_basicCells.lib   \
    ${LIB_DIR}/fast_vdd1v0_multibitsDFF.lib ]

# RC corners: worst (125C) and best (-40C) wire resistance
create_rc_corner -name rc_worst \
    -qx_tech_file ${QRC_TECH} -cap_table ${CAP_TABLE} -temperature 125
create_rc_corner -name rc_best \
    -qx_tech_file ${QRC_TECH} -cap_table ${CAP_TABLE} -temperature -40

# Constraint mode: the SDC that Genus wrote
create_constraint_mode -name func_mode \
    -sdc_files [list ${SYN_OUT}/${DESIGN_NAME}_out.sdc]

# Delay corners = library set + RC corner
create_delay_corner -name dc_setup -library_set libs_slow -rc_corner rc_worst
create_delay_corner -name dc_hold  -library_set libs_fast -rc_corner rc_best

# Analysis views = constraint mode + delay corner
create_analysis_view -name view_setup -constraint_mode func_mode -delay_corner dc_setup
create_analysis_view -name view_hold  -constraint_mode func_mode -delay_corner dc_hold

set_analysis_view -setup [list view_setup] -hold [list view_hold]
