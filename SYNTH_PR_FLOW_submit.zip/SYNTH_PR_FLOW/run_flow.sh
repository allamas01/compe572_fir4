#!/usr/bin/env bash
# =============================================================================
# File   : run_flow.sh
# Design : fir4 — 4-tap symmetric FIR filter [1,3,3,1]/8
# PDK    : gpdk045 (45 nm), gsclib045 standard cells
# Tools  : Cadence Genus 25.x, Innovus 25.x, Xcelium 25.x, Conformal 21.x
#
# 10-stage RTL-to-GDS pipeline:
#
#   Stage       Description                             Log file
#   ----------  --------------------------------------  ---------------------------
#   clean       Remove all generated artifacts          (none)
#   matlab      MATLAB golden model + test vectors      matlab/fir4_run_all.log
#   rtl         RTL simulation (Xcelium)                output/rtl_sim.log
#   synth       Genus synthesis + DFT scan insertion     output/genus_fir4.log
#   lec_synth   Post-synth LEC (RTL vs synth netlist)   fv/fir4/reports/lec_synth.log
#   pnr         Innovus place-and-route (6 sub-stages)  innovus/output/innovus_run_all.log
#   cdl         Innovus CDL export for LVS              innovus/output/write_cdl.log
#   gls_func    Functional gate-level simulation        output/gls_functional.log
#   gls_time    Timing GLS with SDF back-annotation     output/gls_timing.log
#   lec         Post-P&R LEC (RTL vs final netlist)     fv/fir4/reports/lec_rtl_vs_final.log
#
# Each stage prints PASS/FAIL + elapsed time. Flow aborts on first failure.
# Exit 0 iff every enabled stage passed.
#
# Timing gate: synthesis and P&R check for VIOLATED paths. Violations
# within TIMING_MARGIN_PS (default 100 ps) are warnings; beyond that
# threshold are hard failures. Innovus optDesign typically recovers
# 100-200 ps through placement optimization and cell sizing.
#
# ─── Usage ──────────────────────────────────────────────────────────────────
#
# Full flow (all 10 stages):
#   bash run_flow.sh
#
# Front-end only (RTL sim + synthesis + post-synth LEC):
#   bash run_flow.sh --rtl-synth
#
# Skip cleanup (keep previous build artifacts):
#   bash run_flow.sh --no-clean
#
# Skip LEC (everything except equivalence checking):
#   bash run_flow.sh --skip-lec
#
# Run a single stage:
#   bash run_flow.sh --only clean
#   bash run_flow.sh --only matlab
#   bash run_flow.sh --only rtl
#   bash run_flow.sh --only synth
#   bash run_flow.sh --only lec_synth
#   bash run_flow.sh --only pnr
#   bash run_flow.sh --only cdl
#   bash run_flow.sh --only gls_func
#   bash run_flow.sh --only gls_time
#   bash run_flow.sh --only lec
#
# Resume from a stage (runs that stage and everything after):
#   bash run_flow.sh --from synth
#   bash run_flow.sh --from pnr
#
# GUI mode (interactive tools with waveform/layout/schematic viewers):
#   bash run_flow.sh --gui                  # full flow, all GUIs
#   bash run_flow.sh --gui --only rtl       # RTL sim in SimVision
#   bash run_flow.sh --gui --only synth     # Genus schematic viewer
#   bash run_flow.sh --gui --only pnr       # Innovus layout viewer
#   bash run_flow.sh --gui --only gls_func  # functional GLS in SimVision
#   bash run_flow.sh --gui --only gls_time  # timing GLS in SimVision
#   bash run_flow.sh --gui --only lec       # Conformal GUI
#   bash run_flow.sh --gui --only lec_synth # post-synth LEC GUI
#   bash run_flow.sh --gui --only matlab    # MATLAB (always -batch; figures go to PDF)
#
# Override timing margin (default 100 ps):
#   TIMING_MARGIN_PS=50  bash run_flow.sh
#
# Override Cadence module name (default cadence_ece):
#   MODULE_NAME=cadence bash run_flow.sh
#
# Help:
#   bash run_flow.sh --help
#
# ─── GUI support per stage ──────────────────────────────────────────────────
#   clean      no GUI
#   matlab     no GUI (always -batch; figures exported as PDFs)
#   rtl        Xcelium SimVision (waveforms)
#   synth      Genus GUI (schematic viewer)
#   lec_synth  Conformal GUI (compare/mapping viewer)
#   pnr        Innovus GUI (layout viewer)
#   cdl        no GUI
#   gls_func   Xcelium SimVision (waveforms)
#   gls_time   Xcelium SimVision (waveforms + SDF timing)
#   lec        Conformal GUI (compare/mapping viewer)
#
# ─── Prerequisites ──────────────────────────────────────────────────────────
# The script wraps each stage with `bash -l -c 'module load cadence_ece && ...'`
# so you do NOT need to load the module first. cadence_ece publishes
# genus/innovus/xrun/lec as Apptainer shell functions (not PATH binaries).
# =============================================================================

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

# ---- ANSI colours (disabled if not a tty) ----------------------------------
if [ -t 1 ]; then
    C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YEL=$'\033[33m'
    C_CYN=$'\033[36m'; C_BLD=$'\033[1m';  C_RST=$'\033[0m'
else
    C_RED= C_GRN= C_YEL= C_CYN= C_BLD= C_RST=
fi

# ---- Stage registry --------------------------------------------------------
STAGES=(
    "clean|Cleanup|"
    "matlab|MATLAB golden + vectors|matlab/fir4_run_all.log"
    "rtl|RTL simulation|output/rtl_sim.log"
    "synth|Genus synthesis|output/genus_fir4.log"
    "lec_synth|LEC post-synth (RTL vs synth netlist)|fv/fir4/reports/lec_synth.log"
    "pnr|Innovus place-and-route|innovus/output/innovus_run_all.log"
    "cdl|Innovus CDL export|innovus/output/write_cdl.log"
    "gls_func|Functional GLS|output/gls_functional.log"
    "gls_time|Timing GLS (SDF)|output/gls_timing.log"
    "lec|Conformal LEC (RTL vs final netlist)|fv/fir4/reports/lec_rtl_vs_final.log"
)

# ---- CLI parsing -----------------------------------------------------------
DO_CLEAN=1
SKIP_LEC=0
STOP_AFTER=""
ONLY=""
FROM=""
GUI=0

while [ $# -gt 0 ]; do
    case "$1" in
        --no-clean)   DO_CLEAN=0 ;;
        --skip-lec)   SKIP_LEC=1 ;;
        --rtl-synth)  STOP_AFTER="lec_synth" ;;
        --gui)        GUI=1 ;;
        --only)       ONLY="$2"; shift ;;
        --from)       FROM="$2"; shift ;;
        -h|--help)    sed -n '2,48p' "$0"; exit 0 ;;
        *)            echo "Unknown option: $1 (try --help)"; exit 2 ;;
    esac
    shift
done

export GUI

# ---- Stage gate ------------------------------------------------------------
stage_enabled() {
    local id="$1"
    if [ -n "$ONLY" ]; then [ "$ONLY" = "$id" ]; return; fi
    if [ -n "$FROM" ]; then
        local hit=0
        for line in "${STAGES[@]}"; do
            local sid="${line%%|*}"
            [ "$sid" = "$FROM" ] && hit=1
            [ $hit -eq 1 ] && [ "$sid" = "$id" ] && return 0
        done
        return 1
    fi
    [ "$id" = "clean" ] && [ $DO_CLEAN -eq 0 ] && return 1
    [ "$id" = "lec"   ] && [ $SKIP_LEC -eq 1 ] && return 1
    # --rtl-synth: run clean, rtl, synth only (stop after synth)
    if [ -n "$STOP_AFTER" ]; then
        local dominated=0
        for line in "${STAGES[@]}"; do
            local sid="${line%%|*}"
            [ "$sid" = "$id" ] && return $dominated
            [ "$sid" = "$STOP_AFTER" ] && dominated=1
        done
        return 1
    fi
    return 0
}

# ---- IMPORTANT: cadence_ece publishes Genus/Innovus/Xrun/LEC as ------------
#                shell FUNCTIONS that call `apptainer exec ...` against
#                a container image (rocky8_cadence.sif). They are NOT
#                plain binaries on PATH. Shell functions are not
#                inherited by child shells, so the only way to reach
#                the real 25.x tools is to spawn each stage inside its
#                OWN `bash -lc 'module load cadence_ece && <cmd>'`.
#                That's what the wrapper below does.
# -----------------------------------------------------------------------------

# Module name is overridable for sites that ship a different name.
export MODULE_NAME="${MODULE_NAME:-cadence_ece}"

# Each stage runs inside `cadence_run` from scripts/with_cadence.sh.
# That helper spawns a login bash, runs `module load $MODULE_NAME` to
# define the apptainer-wrapper shell functions for genus/innovus/xrun/
# lec, then runs the stage command. Sub-scripts (run_rtl_sim.sh,
# run_gls.sh, fv/fir4/run_lec.sh, pvs/scripts/run_*.sh) all use the
# same helper, so they are safe to invoke either via run_flow.sh OR
# directly from a user shell.
. "$PROJECT_DIR/scripts/with_cadence.sh"
_run_in_module_env() { cadence_run "$@"; }

# ---- Pre-flight: can the wrapper actually find genus? ----------------------
# `command -v genus` only works after the module load + apptainer-wrapper
# function is defined, so we have to ask through the wrapper.
PROBE_GENUS=$(_run_in_module_env "command -v genus 2>/dev/null" 2>/dev/null)
if [ -z "$PROBE_GENUS" ]; then
    echo "${C_RED}${C_BLD}ERROR:${C_RST} cannot resolve 'genus' inside"
    echo "       'bash -l -c module load $MODULE_NAME'."
    echo ""
    echo "  Verify in your shell:"
    echo "      module purge"
    echo "      module load $MODULE_NAME"
    echo "      type genus           # should show a function (apptainer wrapper)"
    echo ""
    echo "  If the module name differs on your site, override:"
    echo "      MODULE_NAME=<name> bash run_flow.sh"
    echo ""
    exit 1
fi
echo "  genus resolves to: $PROBE_GENUS"

# ---- Stage runner ----------------------------------------------------------
declare -A STAGE_ELAPSED STAGE_STATUS STAGE_DETAIL

run_stage() {
    local id="$1" label="$2" cmd="$3"
    echo ""
    echo "${C_CYN}${C_BLD}===== [$id] $label =====${C_RST}"
    echo "  cmd: $cmd"
    local t0=$(date +%s)
    # Wrap every stage in `bash -l -c module load ...` so the
    # apptainer shell functions for genus/innovus/xrun/lec are
    # defined for the duration of that stage.
    ( _run_in_module_env "$cmd" )
    local rc=$?
    local t1=$(date +%s)
    STAGE_ELAPSED[$id]=$((t1 - t0))
    if [ $rc -eq 0 ]; then
        STAGE_STATUS[$id]="PASS"
        echo "  ${C_GRN}PASS${C_RST}  (${STAGE_ELAPSED[$id]}s)"
    else
        STAGE_STATUS[$id]="FAIL"
        echo "  ${C_RED}FAIL${C_RST}  (rc=$rc, ${STAGE_ELAPSED[$id]}s)"
        return $rc
    fi
}

# ---- Banner ----------------------------------------------------------------
echo "${C_BLD}${C_CYN}=========================================================="
echo "  fir4 end-to-end flow  --  run_flow.sh"
echo "==========================================================${C_RST}"
date
echo ""
echo "  module name : $MODULE_NAME"
echo "  Each stage runs as:  bash -l -c 'module load $MODULE_NAME && <cmd>'"
echo "  This is required because cadence_ece publishes genus/innovus/xrun/lec"
echo "  as Apptainer-container shell functions, not as plain binaries on PATH."
echo "  Resolved 'genus' inside the wrapper: $PROBE_GENUS"

# Quick version check via the wrapper.
v=$(_run_in_module_env 'genus -version 2>/dev/null | head -1' 2>/dev/null)
[ -n "$v" ] && echo "  genus version : $v"
echo ""

OVERALL_RC=0
START_TS=$(date +%s)

# ---- Stages ----------------------------------------------------------------
# Each line: skip if stage is disabled (--only / --from / --skip-lec);
# skip if a PREVIOUS stage failed (OVERALL_RC != 0). A SKIPPED stage
# must NOT set OVERALL_RC (that was the bug with the old `|| OVERALL_RC=$?`
# pattern on a single compound line — the `stage_enabled` return code
# leaked into OVERALL_RC and killed everything downstream).
run_if_enabled() {
    local id="$1"; shift
    [ $OVERALL_RC -ne 0 ] && return 0       # prior failure → skip silently
    stage_enabled "$id"   || return 0        # stage disabled → skip silently
    run_stage "$id" "$@"  || OVERALL_RC=$?   # run; capture real failure
}

# Post-stage timing check: greps the report for VIOLATED paths.
# Violations within TIMING_MARGIN_PS are warnings (Innovus P&R can recover);
# violations beyond that threshold are hard failures.
TIMING_MARGIN_PS=${TIMING_MARGIN_PS:-100}

check_timing() {
    local label="$1" rpt="$2"
    if [ ! -f "$rpt" ]; then
        echo "  ${C_YEL}WARN:${C_RST} timing report not found: $rpt"
        return 0   # don't fail — report may not exist if stage was partial
    fi
    local viols
    viols=$(grep -c "VIOLATED" "$rpt" 2>/dev/null || true)
    if [ "$viols" -gt 0 ]; then
        # Extract worst negative slack (most negative number) from VIOLATED lines.
        # Format: "Path N: VIOLATED (-28 ps) Setup Check ..."
        local wns
        wns=$(grep "VIOLATED" "$rpt" \
            | grep -oE '\(-[0-9.]+ ps\)' \
            | grep -oE '\-[0-9.]+' \
            | sort -g | head -1)

        if [ -n "$wns" ]; then
            # Compare |WNS| against margin (awk handles float comparison)
            local within_margin
            within_margin=$(awk -v w="$wns" -v m="$TIMING_MARGIN_PS" \
                'BEGIN { print (w > -m) ? 1 : 0 }')
            if [ "$within_margin" -eq 1 ]; then
                echo "  ${C_YEL}TIMING WARN:${C_RST} $viols violated path(s), WNS=${wns} ps (within ${TIMING_MARGIN_PS} ps margin — Innovus can recover)"
                grep "VIOLATED" "$rpt" | head -3 | sed 's/^/    /'
                return 0
            else
                echo "  ${C_RED}${C_BLD}TIMING FAIL:${C_RST} $viols violated path(s), WNS=${wns} ps (exceeds ${TIMING_MARGIN_PS} ps margin)"
                grep "VIOLATED" "$rpt" | head -3 | sed 's/^/    /'
                return 1
            fi
        else
            echo "  ${C_RED}${C_BLD}TIMING FAIL:${C_RST} $viols violated path(s) in $rpt (could not parse slack)"
            grep "VIOLATED" "$rpt" | head -3 | sed 's/^/    /'
            return 1
        fi
    else
        echo "  ${C_GRN}TIMING CLEAN:${C_RST} 0 violated paths in $rpt"
        return 0
    fi
}

# ---- GUI-aware command builders ---------------------------------------------
# When --gui is passed, stages that support interactive mode get their
# GUI flags. Stages that have no GUI mode ignore the flag.
MATLAB_CMD="cd matlab && matlab -batch 'fir4_run_all' -logfile ../matlab/fir4_run_all.log && cd .."
RTL_CMD="bash scripts/run_rtl_sim.sh"
SYNTH_CMD="genus -batch -f scripts/syn.tcl -log output/genus_fir4.log"
LEC_SYNTH_CMD="bash fv/fir4/run_lec_synth.sh"
PNR_CMD="innovus -batch -files innovus/scripts/run_all.tcl -log innovus/output/innovus_run_all.log"
CDL_CMD="innovus -batch -files innovus/scripts/write_cdl.tcl -log innovus/output/write_cdl.log"
GLS_FUNC_CMD="bash scripts/run_gls.sh"
GLS_TIME_CMD="TIMING=1 bash scripts/run_gls.sh"
LEC_CMD="bash fv/fir4/run_lec.sh"

if [ $GUI -eq 1 ]; then
    echo "  ${C_CYN}--gui mode: stages with GUI support will launch interactively${C_RST}"
    echo ""
    # MATLAB: open desktop interactively, BLOCK until the user closes it.
    # The flow must wait for fir4_run_all.m to finish writing the hex
    # files before the RTL stage runs. Closing the MATLAB window via
    # the title-bar X can return a non-zero exit code, which would
    # otherwise fail the stage -- wrap in `|| true` so any close works.
    MATLAB_CMD="cd matlab && (matlab -r 'fir4_run_all' || true) && cd .."
    # RTL sim: SimVision waveform viewer
    RTL_CMD="GUI=1 bash scripts/run_rtl_sim.sh"
    # Synthesis: Genus GUI with -gui flag. Without -gui, Genus runs the
    # script and exits at stdin EOF even though -batch is missing.
    # -gui launches the Genus GUI window; -f sources syn.tcl at startup;
    # Genus stays open after the script finishes so you can browse the
    # schematic, timing, and report windows interactively.
    SYNTH_CMD="genus -gui -f scripts/syn.tcl -log output/genus_fir4.log"
    # P&R: Innovus opens the GUI by default when -batch is omitted.
    # Innovus 25.x does NOT accept -gui (IMPSYT-468); just drop -batch.
    # The session stays open after run_all.tcl sources `win; fit` so you
    # can inspect the final floorplan and routed layout interactively.
    PNR_CMD="innovus -files innovus/scripts/run_all.tcl -log innovus/output/innovus_run_all.log"
    # GLS: SimVision
    GLS_FUNC_CMD="GUI=1 bash scripts/run_gls.sh"
    GLS_TIME_CMD="GUI=1 TIMING=1 bash scripts/run_gls.sh"
    # LEC: Conformal GUI (schematic/mapping manager)
    LEC_SYNTH_CMD="GUI=1 bash fv/fir4/run_lec_synth.sh"
    LEC_CMD="GUI=1 bash fv/fir4/run_lec.sh"
fi

run_if_enabled clean    "Cleanup"                 "bash clean.sh"
run_if_enabled matlab   "MATLAB golden + vectors"  "$MATLAB_CMD"
run_if_enabled rtl      "RTL simulation"          "$RTL_CMD"
run_if_enabled synth    "Genus synthesis"          "$SYNTH_CMD"

# ── Post-synthesis timing gate ──
if [ $OVERALL_RC -eq 0 ] && [ -n "${STAGE_STATUS[synth]:-}" ] \
   && [ "${STAGE_STATUS[synth]}" = "PASS" ]; then
    if ! check_timing "post-synth" "output/fir4_timing.rpt"; then
        STAGE_STATUS[synth]="FAIL"
        OVERALL_RC=1
    fi
fi

# ── Post-synthesis LEC (RTL vs Genus netlist) — catches retiming issues
#    BEFORE committing to a multi-hour P&R run ──
run_if_enabled lec_synth "Post-synth LEC (RTL vs synth netlist)" "$LEC_SYNTH_CMD"

run_if_enabled pnr      "Innovus place-and-route"  "$PNR_CMD"

# ── Post-P&R timing gate ──
if [ $OVERALL_RC -eq 0 ] && [ -n "${STAGE_STATUS[pnr]:-}" ] \
   && [ "${STAGE_STATUS[pnr]}" = "PASS" ]; then
    if ! check_timing "signoff setup" "innovus/output/fir4_signoff_setup.rpt"; then
        STAGE_STATUS[pnr]="FAIL"
        OVERALL_RC=1
    fi
    if [ $OVERALL_RC -eq 0 ]; then
        if ! check_timing "signoff hold" "innovus/output/fir4_signoff_hold.rpt"; then
            STAGE_STATUS[pnr]="FAIL"
            OVERALL_RC=1
        fi
    fi
fi

run_if_enabled cdl      "Innovus CDL export"       "$CDL_CMD"
run_if_enabled gls_func "Functional GLS"           "$GLS_FUNC_CMD"
run_if_enabled gls_time "Timing GLS (SDF)"         "$GLS_TIME_CMD"
run_if_enabled lec      "Conformal LEC"            "$LEC_CMD"

# ---- Collect design metrics from reports -----------------------------------
collect_metrics() {
    local rpt val

    # MATLAB: vector count
    if [ -f "tb/stim_vectors.hex" ]; then
        val=$(wc -l < tb/stim_vectors.hex 2>/dev/null | tr -d ' ')
        STAGE_DETAIL[matlab]="${val} test vectors"
    fi

    # RTL sim: pass/fail count
    rpt="output/rtl_sim.log"
    if [ -f "$rpt" ]; then
        val=$(grep -oE '[0-9]+/[0-9]+ outputs matched' "$rpt" 2>/dev/null | head -1)
        [ -n "$val" ] && STAGE_DETAIL[rtl]="$val"
    fi

    # Synthesis: WNS, area, gates, power
    if [ -f "output/fir4_timing.rpt" ]; then
        local wns=$(grep "VIOLATED\|MET" "output/fir4_timing.rpt" 2>/dev/null | head -1 | grep -oE '\(-?[0-9.]+' | head -1 | tr -d '(')
        [ -z "$wns" ] && wns=$(grep "MET" "output/fir4_timing.rpt" 2>/dev/null | head -1 | grep -oE '\([0-9.]+' | head -1 | tr -d '(')
        local area=$(grep -E "^Total" "output/fir4_area.rpt" 2>/dev/null | head -1 | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\./) {print $i; exit}}')
        local gates_seq=$(grep -E "sequential" "output/fir4_gates.rpt" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+$/) {print $i; exit}}')
        local gates_comb=$(grep -E "combinational" "output/fir4_gates.rpt" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+$/) {print $i; exit}}')
        local pwr=$(grep -E "Total" "output/fir4_power.rpt" 2>/dev/null | tail -1 | awk '{for(i=1;i<=NF;i++) if($i ~ /^[0-9]+\./) {printf "%.2f", $i; exit}}')
        local detail=""
        [ -n "$wns" ] && detail="WNS=${wns}ps"
        [ -n "$area" ] && detail="$detail  area=${area}um2"
        [ -n "$gates_seq" ] && detail="$detail  ${gates_seq}seq/${gates_comb:-?}comb"
        [ -n "$pwr" ] && detail="$detail  pwr=${pwr}mW"
        [ -n "$detail" ] && STAGE_DETAIL[synth]="$detail"
    fi

    # Post-synth LEC: EQ/NON-EQ counts
    rpt="fv/fir4/reports/lec_synth.rpt"
    if [ -f "$rpt" ]; then
        local eq=$(awk '/Number of EQ compare points/ {for(i=1;i<=NF;i++) if($i~/^[0-9]+$/) print $i}' "$rpt" | head -1)
        local ne=$(awk '/Number of NON-EQ compare points/ {for(i=1;i<=NF;i++) if($i~/^[0-9]+$/) print $i}' "$rpt" | head -1)
        [ -n "$eq" ] && STAGE_DETAIL[lec_synth]="${eq}EQ ${ne:-0}NON-EQ"
    fi

    # P&R: signoff WNS setup + hold
    if [ -f "innovus/output/fir4_signoff_setup.rpt" ]; then
        local swns=$(grep -E "VIOLATED|MET" "innovus/output/fir4_signoff_setup.rpt" 2>/dev/null | head -1 | grep -oE '\(-?[0-9.]+|\([0-9.]+' | head -1 | tr -d '(')
        local hwns=$(grep -E "VIOLATED|MET" "innovus/output/fir4_signoff_hold.rpt" 2>/dev/null | head -1 | grep -oE '\(-?[0-9.]+|\([0-9.]+' | head -1 | tr -d '(')
        local detail=""
        [ -n "$swns" ] && detail="setup=${swns}ps"
        [ -n "$hwns" ] && detail="$detail  hold=${hwns}ps"
        [ -n "$detail" ] && STAGE_DETAIL[pnr]="$detail"
    fi

    # Functional GLS: match count
    rpt="output/gls_functional.log"
    if [ -f "$rpt" ]; then
        val=$(grep -oE '[0-9]+/[0-9]+ outputs matched' "$rpt" 2>/dev/null | head -1)
        [ -n "$val" ] && STAGE_DETAIL[gls_func]="$val"
    fi

    # Timing GLS: match count + SDF annotation %
    rpt="output/gls_timing.log"
    if [ -f "$rpt" ]; then
        val=$(grep -oE '[0-9]+/[0-9]+ outputs matched' "$rpt" 2>/dev/null | head -1)
        local sdf_pct=$(grep "Path Delays" "$rpt" 2>/dev/null | grep -oE '[0-9]+\.[0-9]+%' | head -1)
        local detail=""
        [ -n "$val" ] && detail="$val"
        [ -n "$sdf_pct" ] && detail="$detail  SDF=${sdf_pct}"
        [ -n "$detail" ] && STAGE_DETAIL[gls_time]="$detail"
    fi

    # Post-P&R LEC: EQ/NON-EQ counts
    rpt="fv/fir4/reports/lec_rtl_vs_final.rpt"
    if [ -f "$rpt" ]; then
        local eq=$(awk '/Number of EQ compare points/ {for(i=1;i<=NF;i++) if($i~/^[0-9]+$/) print $i}' "$rpt" | head -1)
        local ne=$(awk '/Number of NON-EQ compare points/ {for(i=1;i<=NF;i++) if($i~/^[0-9]+$/) print $i}' "$rpt" | head -1)
        [ -n "$eq" ] && STAGE_DETAIL[lec]="${eq}EQ ${ne:-0}NON-EQ"
    fi
}

collect_metrics

# ---- Summary ---------------------------------------------------------------
END_TS=$(date +%s)
echo ""
# Terminal width (default 100 if tput unavailable); clamp to [80, 160]
TERM_WIDTH=$(tput cols 2>/dev/null || echo 100)
[ "$TERM_WIDTH" -lt 80 ]  && TERM_WIDTH=80
[ "$TERM_WIDTH" -gt 160 ] && TERM_WIDTH=160

# Build separator line the width of the terminal
SEP=""
for ((k=0; k<TERM_WIDTH; k++)); do SEP="${SEP}="; done

echo "${C_BLD}${C_CYN}${SEP}${C_RST}"
echo "${C_BLD}${C_CYN}  FLOW SUMMARY${C_RST}"
echo "${C_BLD}${C_CYN}${SEP}${C_RST}"
printf "%-10s %-28s %6s  %-6s  %s\n" "STAGE" "LABEL" "TIME" "STATUS" "DETAILS"
printf "%-10s %-28s %6s  %-6s  %s\n" "----------" "----------------------------" "------" "------" "-------"

# Details that fit on one line (<= DETAIL_INLINE chars) stay inline;
# longer details print on an indented continuation line so columns
# never get misaligned by wide metric strings.
DETAIL_INLINE=$(( TERM_WIDTH - 58 ))   # columns left over for DETAILS on same row
[ "$DETAIL_INLINE" -lt 20 ] && DETAIL_INLINE=20

for line in "${STAGES[@]}"; do
    id="${line%%|*}"; rest="${line#*|}"; label="${rest%%|*}"
    status="${STAGE_STATUS[$id]:-SKIP}"
    elapsed="${STAGE_ELAPSED[$id]:-}"
    detail="${STAGE_DETAIL[$id]:-}"
    case "$status" in PASS) col=$C_GRN ;; FAIL) col=$C_RED ;; *) col=$C_YEL ;; esac
    [ -n "$elapsed" ] && elapsed="${elapsed}s"

    if [ ${#detail} -le $DETAIL_INLINE ]; then
        # short detail: fits on same line
        printf "%-10s %-28s %6s  %s%-6s%s  %s\n" \
            "$id" "$label" "$elapsed" "$col" "$status" "$C_RST" "$detail"
    else
        # long detail: print status row then continuation on next line
        printf "%-10s %-28s %6s  %s%-6s%s\n" \
            "$id" "$label" "$elapsed" "$col" "$status" "$C_RST"
        # Indent continuation so it's visually grouped with its stage row
        printf "%-10s %-28s %6s  %-6s  ${C_CYN}>${C_RST} %s\n" \
            "" "" "" "" "$detail"
    fi
done
echo "${C_BLD}${C_CYN}${SEP}${C_RST}"
printf "  Total wall time: %d s\n" "$((END_TS - START_TS))"
echo ""
if [ $OVERALL_RC -eq 0 ]; then
    echo "${C_GRN}${C_BLD}  RESULT: PASS${C_RST}"
else
    echo "${C_RED}${C_BLD}  RESULT: FAIL${C_RST}"
fi
exit $OVERALL_RC
