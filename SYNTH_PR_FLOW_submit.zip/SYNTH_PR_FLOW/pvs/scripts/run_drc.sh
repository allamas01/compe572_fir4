#!/bin/bash
# =============================================================================
# File   : pvs/scripts/run_drc.sh
# Purpose: Run PVS DRC on fir4.gds using gpdk045 rule deck
#
# Usage  : source pvs/scripts/pvs_setup.sh
#          bash pvs/scripts/run_drc.sh
# =============================================================================

set -e

source "$(dirname "$0")/pvs_setup.sh"

RUNSET="${PROJECT_DIR}/pvs/runsets/fir4_drc.pvl"
DRC_OUT="${PVS_OUT_DRC}"

echo "============================================================"
echo "  PVS DRC — fir4"
echo "  GDS     : ${GDS_FILE}"
echo "  Runset  : ${RUNSET}"
echo "  Output  : ${DRC_OUT}"
echo "============================================================"

mkdir -p "${DRC_OUT}"

# Pull in cadence_run() so 'pvs' is invoked inside `bash -l -c
# 'module load cadence_ece && ...'`. cadence_ece publishes pvs as an
# Apptainer-container shell function; loading it inside a child bash
# is the only way to reach the real PVS binary. See README.txt.
PROJECT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
. "${PROJECT_DIR}/scripts/with_cadence.sh"

# ─── Run PVS DRC ──────────────────────────────────────────────────────────────
# -turbo 4 = number of parallel CPU cores
cadence_run "pvs -drc \
    -ruleFile      '${RUNSET}'  \
    -layoutPath    '${GDS_FILE}' \
    -layoutPrimary 'fir4'        \
    -resultsDir    '${DRC_OUT}'  \
    -log           '${DRC_OUT}/pvs_drc.log' \
    -turbo 4 -verbose"

# ─── Check results ────────────────────────────────────────────────────────────
echo ""
echo "============================================================"
echo "  DRC Summary"
echo "============================================================"

if [ -f "${DRC_OUT}/fir4_drc_summary.txt" ]; then
    cat "${DRC_OUT}/fir4_drc_summary.txt"
else
    echo "  Summary file not found — check log: ${DRC_OUT}/pvs_drc.log"
fi

# ─── Exit status ──────────────────────────────────────────────────────────────
if grep -q "DRC CLEAN" "${DRC_OUT}/fir4_drc_summary.txt" 2>/dev/null; then
    echo ""
    echo "  RESULT: DRC CLEAN"
    exit 0
else
    echo ""
    echo "  RESULT: DRC VIOLATIONS FOUND — review ${DRC_OUT}/fir4_drc.results"
    exit 1
fi
