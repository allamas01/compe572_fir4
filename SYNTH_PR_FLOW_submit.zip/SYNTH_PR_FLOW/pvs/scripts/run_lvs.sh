#!/bin/bash
# =============================================================================
# File   : pvs/scripts/run_lvs.sh
# Purpose: Run PVS LVS — layout (GDS) vs schematic (CDL) for fir4
#
# Prerequisites:
#   - gds/fir4.gds     produced by Innovus streamOut (06_signoff.tcl)
#   - cdl/fir4.cdl     produced by Innovus saveNetlist (write_cdl.tcl)
#
# Usage  : source pvs/scripts/pvs_setup.sh
#          bash pvs/scripts/run_lvs.sh
# =============================================================================

set -e

source "$(dirname "$0")/pvs_setup.sh"

RUNSET="${PROJECT_DIR}/pvs/runsets/fir4_lvs.pvl"
LVS_OUT="${PVS_OUT_LVS}"

echo "============================================================"
echo "  PVS LVS — fir4"
echo "  GDS (layout)    : ${GDS_FILE}"
echo "  CDL (schematic) : ${CDL_FILE}"
echo "  Runset          : ${RUNSET}"
echo "  Output          : ${LVS_OUT}"
echo "============================================================"

# ─── Verify inputs exist ──────────────────────────────────────────────────────
if [ ! -f "${GDS_FILE}" ]; then
    echo "ERROR: GDS not found: ${GDS_FILE}"
    echo "       Run Innovus 06_signoff.tcl first"
    exit 1
fi

if [ ! -f "${CDL_FILE}" ]; then
    echo "ERROR: CDL not found: ${CDL_FILE}"
    echo "       Run Innovus write_cdl.tcl first"
    exit 1
fi

mkdir -p "${LVS_OUT}"

# Pull in cadence_run() so 'pvs' is invoked inside `bash -l -c
# 'module load cadence_ece && ...'`. cadence_ece publishes pvs as an
# Apptainer-container shell function. See README.txt.
PROJECT_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
. "${PROJECT_DIR}/scripts/with_cadence.sh"

# ─── Run PVS LVS ──────────────────────────────────────────────────────────────
cadence_run "pvs -lvs \
    -ruleFile      '${RUNSET}'    \
    -layoutPath    '${GDS_FILE}'  \
    -layoutPrimary 'fir4'         \
    -sourcePath    '${CDL_FILE}'  \
    -sourcePrimary 'fir4'         \
    -resultsDir    '${LVS_OUT}'   \
    -log           '${LVS_OUT}/pvs_lvs.log' \
    -turbo 4 -verbose"

# ─── Check results ────────────────────────────────────────────────────────────
echo ""
echo "============================================================"
echo "  LVS Summary"
echo "============================================================"

if [ -f "${LVS_OUT}/fir4_lvs_summary.txt" ]; then
    cat "${LVS_OUT}/fir4_lvs_summary.txt"
else
    echo "  Summary file not found — check log: ${LVS_OUT}/pvs_lvs.log"
fi

# ─── Exit status ──────────────────────────────────────────────────────────────
if grep -q "LVS CLEAN" "${LVS_OUT}/fir4_lvs_summary.txt" 2>/dev/null; then
    echo ""
    echo "  RESULT: LVS CLEAN — layout matches schematic"
    exit 0
else
    echo ""
    echo "  RESULT: LVS MISMATCH — review ${LVS_OUT}/fir4_lvs.report"
    exit 1
fi
