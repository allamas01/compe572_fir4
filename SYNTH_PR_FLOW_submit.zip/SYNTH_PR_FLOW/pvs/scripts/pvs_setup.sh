#!/bin/bash
# =============================================================================
# File   : pvs/scripts/pvs_setup.sh
# Purpose: Set up shell environment for Cadence PVS
#          Source this before running any PVS script:
#            source pvs/scripts/pvs_setup.sh
# =============================================================================

# ─── Cadence tool installation ────────────────────────────────────────────────
export CDS_INST_DIR="/tools/cadence/INNOVUS"       # adjust to your installation
export PVS_HOME="${CDS_INST_DIR}/tools/pvs"

# ─── gpdk045 rule deck location ───────────────────────────────────────────────
export GPDK045_HOME="/path/to/gpdk045"
export PVS_RULE_DIR="${GPDK045_HOME}/pvs/runsets"

# ─── Project paths ────────────────────────────────────────────────────────────
export PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export GDS_FILE="${PROJECT_DIR}/gds/fir4.gds"
export CDL_FILE="${PROJECT_DIR}/cdl/fir4.cdl"
export PVS_OUT_DRC="${PROJECT_DIR}/pvs/output/drc"
export PVS_OUT_LVS="${PROJECT_DIR}/pvs/output/lvs"

# ─── Add PVS to PATH ──────────────────────────────────────────────────────────
export PATH="${PVS_HOME}/bin:${PATH}"
export LD_LIBRARY_PATH="${PVS_HOME}/lib:${LD_LIBRARY_PATH}"

# ─── License ──────────────────────────────────────────────────────────────────
export CDS_LIC_FILE="5280@your_license_server"     # adjust to your server

echo ""
echo "[pvs_setup] Environment ready"
echo "  PVS_HOME    : ${PVS_HOME}"
echo "  RULE_DIR    : ${PVS_RULE_DIR}"
echo "  GDS         : ${GDS_FILE}"
echo "  CDL         : ${CDL_FILE}"
echo "  DRC output  : ${PVS_OUT_DRC}"
echo "  LVS output  : ${PVS_OUT_LVS}"
echo ""
