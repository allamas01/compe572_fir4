#!/bin/bash
# =============================================================================
# File   : pvs/scripts/run_pvs_all.sh
# Purpose: Run full PVS flow: DRC then LVS, with pass/fail summary
#
# Usage  : bash pvs/scripts/run_pvs_all.sh
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

source "${SCRIPT_DIR}/pvs_setup.sh"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   fir4 PVS Physical Verification Flow               ║"
echo "╚══════════════════════════════════════════════════════╝"

# Pull in cadence_run() so 'innovus' is invoked inside `bash -l -c
# 'module load cadence_ece && ...'`. cadence_ece publishes innovus as
# an Apptainer-container shell function. See README.txt.
. "${PROJECT_DIR}/scripts/with_cadence.sh"

# ─── Step 1: Export CDL from Innovus (if not already done) ───────────────────
if [ ! -f "${CDL_FILE}" ]; then
    echo ""
    echo ">>> CDL not found — generating from Innovus..."
    cadence_run "innovus -batch \
        -files '${PROJECT_DIR}/innovus/scripts/write_cdl.tcl' \
        -log   '${PROJECT_DIR}/innovus/output/write_cdl.log'"
fi

# ─── Step 2: DRC ─────────────────────────────────────────────────────────────
echo ""
echo "========== STEP 1 / 2 : DRC =========="
DRC_STATUS=0
bash "${SCRIPT_DIR}/run_drc.sh" || DRC_STATUS=$?

# ─── Step 3: LVS ─────────────────────────────────────────────────────────────
echo ""
echo "========== STEP 2 / 2 : LVS =========="
LVS_STATUS=0
bash "${SCRIPT_DIR}/run_lvs.sh" || LVS_STATUS=$?

# ─── Final summary ────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   PVS RESULTS SUMMARY                               ║"
echo "╠══════════════════════════════════════════════════════╣"

if [ $DRC_STATUS -eq 0 ]; then
    echo "║   DRC : CLEAN  ✓                                    ║"
else
    echo "║   DRC : VIOLATIONS FOUND  ✗                         ║"
    echo "║         ${PVS_OUT_DRC}/fir4_drc.results"
fi

if [ $LVS_STATUS -eq 0 ]; then
    echo "║   LVS : CLEAN  ✓                                    ║"
else
    echo "║   LVS : MISMATCH FOUND  ✗                           ║"
    echo "║         ${PVS_OUT_LVS}/fir4_lvs.report"
fi

echo "╚══════════════════════════════════════════════════════╝"
echo ""

# ─── Exit non-zero if either check failed ─────────────────────────────────────
[ $DRC_STATUS -eq 0 ] && [ $LVS_STATUS -eq 0 ] && exit 0 || exit 1
